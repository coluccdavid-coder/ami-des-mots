// Ami des mots — textes de l'interface. Une langue d'interface absente
// d'ici n'est pas proposée : jamais de texte français à sa place.
// Les fonctions reçoivent un nombre ou un mot.
window.LANGUES_APPRENDRE = {
  fr:'Français', en:'English', es:'Español', it:'Italiano', pt:'Português', de:'Deutsch',
  ar:'العربية', tr:'Türkçe', pl:'Polski', ja:'日本語', uk:'Українська', ko:'한국어',
  dz:'الدارجة الجزائرية', ma:'الدارجة المغربية', tn:'الدارجة التونسية', kab:'Taqbaylit'
};
window.TEXTES = {
fr:{
  accroche:"Des mots en images, et un hibou pour jouer.",
  je_parle:"Je parle", j_apprends:"J'apprends", jouer:"Jouer", plumes:"plumes",
  serie:n => n > 1 ? `${n} jours de suite` : `1 jour`, objectif:"Objectif du jour : une partie", objectif_fait:"Objectif du jour atteint ✓",
  th_animaux:"Animaux", th_manger:"À table", th_maison:"La maison", th_habits:"Habits", th_nature:"Nature", th_ville:"En ville", th_musique:"Musique et fête", th_atelier:"Atelier et sciences",
  j_decouvrir:"Découvrir", j_ecoute:"Écoute et trouve", j_quel_mot:"Quel mot ?", j_memoire:"Mémoire", j_lettres:"Lettres en vrac",
  a_decouvrir:"Regardez, écoutez, retournez la carte.", a_ecoute:"Écoutez, puis touchez la bonne image.", a_quel_mot:"Quel est le nom de cette image ?", a_memoire:"Retrouvez chaque image et son mot.", a_lettres:"Remettez les lettres dans l'ordre.",
  bravo:["Bravo !", "Super !", "Oui, c'est ça !"], rate:"Pas tout à fait. Essayez encore !", c_etait:m => `C'était : ${m}`,
  fin_titre:"Partie terminée !", fin_plumes:n => `+${n} plumes`, rejouer:"Rejouer", autre_jeu:"Autre jeu", themes:"Thèmes",
  suivant:"Suivant", ecouter:"Écouter", retour:"Retour", effacer:"Effacer", retourner:"Touchez la carte pour la retourner.",
  vestiaire:"Le vestiaire d'Ami", acc_echarpe:"Écharpe", acc_lunettes:"Lunettes", acc_noeud:"Nœud papillon", acc_chapeau:"Chapeau", acc_couronne:"Couronne",
  a_partir:n => `À ${n} plumes`, porte:"Ami le porte", mettre:"Lui mettre", enlever:"Lui enlever", nouveau:"Nouveau dans le vestiaire !",
  verrou:"Version complète", verrou_aide:"Ce thème fait partie de la version complète.",
  peu_de_mots:"Pas encore assez de mots dans ce thème pour cette langue.", sans_voix:"Pas encore de voix pour ce mot.",
  apropos:"À propos", apropos_texte:"Ami des mots est un jeu pour apprendre et réviser des mots en images, dans 16 langues. C'est un jeu : il ne soigne rien et ne remplace aucun professionnel. Rien n'est envoyé : vos progrès restent sur cet appareil, sans compte et sans publicité.",
  effacer_progres:"Effacer mes progrès", confirmer:"Touchez encore pour confirmer"
},
en:{
  accroche:"Words in pictures, and an owl to play with.",
  je_parle:"I speak", j_apprends:"I'm learning", jouer:"Play", plumes:"feathers",
  serie:n => n > 1 ? `${n} days in a row` : `1 day`, objectif:"Today's goal: one game", objectif_fait:"Today's goal reached ✓",
  th_animaux:"Animals", th_manger:"At the table", th_maison:"The house", th_habits:"Clothes", th_nature:"Nature", th_ville:"In town", th_musique:"Music and fun", th_atelier:"Workshop and science",
  j_decouvrir:"Discover", j_ecoute:"Listen and find", j_quel_mot:"Which word?", j_memoire:"Memory", j_lettres:"Jumbled letters",
  a_decouvrir:"Look, listen, flip the card.", a_ecoute:"Listen, then tap the right picture.", a_quel_mot:"What is this picture called?", a_memoire:"Match each picture with its word.", a_lettres:"Put the letters back in order.",
  bravo:["Well done!", "Great!", "Yes, that's it!"], rate:"Not quite. Try again!", c_etait:m => `It was: ${m}`,
  fin_titre:"Game over!", fin_plumes:n => `+${n} feathers`, rejouer:"Play again", autre_jeu:"Another game", themes:"Themes",
  suivant:"Next", ecouter:"Listen", retour:"Back", effacer:"Clear", retourner:"Tap the card to flip it.",
  vestiaire:"Ami's wardrobe", acc_echarpe:"Scarf", acc_lunettes:"Glasses", acc_noeud:"Bow tie", acc_chapeau:"Hat", acc_couronne:"Crown",
  a_partir:n => `At ${n} feathers`, porte:"Ami is wearing it", mettre:"Put it on", enlever:"Take it off", nouveau:"New in the wardrobe!",
  verrou:"Full version", verrou_aide:"This theme is part of the full version.",
  peu_de_mots:"Not enough words in this theme for this language yet.", sans_voix:"No voice for this word yet.",
  apropos:"About", apropos_texte:"Ami des mots is a game to learn and review words in pictures, in 16 languages. It is a game: it does not treat anything and does not replace any professional. Nothing is sent: your progress stays on this device, with no account and no ads.",
  effacer_progres:"Erase my progress", confirmer:"Tap again to confirm"
},
es:{
  accroche:"Palabras en imágenes, y un búho para jugar.",
  je_parle:"Hablo", j_apprends:"Aprendo", jouer:"Jugar", plumes:"plumas",
  serie:n => n > 1 ? `${n} días seguidos` : `1 día`, objectif:"Objetivo de hoy: una partida", objectif_fait:"Objetivo de hoy cumplido ✓",
  th_animaux:"Animales", th_manger:"A la mesa", th_maison:"La casa", th_habits:"Ropa", th_nature:"Naturaleza", th_ville:"En la ciudad", th_musique:"Música y fiesta", th_atelier:"Taller y ciencias",
  j_decouvrir:"Descubrir", j_ecoute:"Escucha y encuentra", j_quel_mot:"¿Qué palabra?", j_memoire:"Memoria", j_lettres:"Letras revueltas",
  a_decouvrir:"Mira, escucha, gira la tarjeta.", a_ecoute:"Escucha y toca la imagen correcta.", a_quel_mot:"¿Cómo se llama esta imagen?", a_memoire:"Encuentra cada imagen y su palabra.", a_lettres:"Pon las letras en orden.",
  bravo:["¡Bravo!", "¡Genial!", "¡Sí, eso es!"], rate:"No del todo. ¡Inténtalo otra vez!", c_etait:m => `Era: ${m}`,
  fin_titre:"¡Partida terminada!", fin_plumes:n => `+${n} plumas`, rejouer:"Volver a jugar", autre_jeu:"Otro juego", themes:"Temas",
  suivant:"Siguiente", ecouter:"Escuchar", retour:"Volver", effacer:"Borrar", retourner:"Toca la tarjeta para girarla.",
  vestiaire:"El armario de Ami", acc_echarpe:"Bufanda", acc_lunettes:"Gafas", acc_noeud:"Pajarita", acc_chapeau:"Sombrero", acc_couronne:"Corona",
  a_partir:n => `Con ${n} plumas`, porte:"Ami lo lleva puesto", mettre:"Ponérselo", enlever:"Quitárselo", nouveau:"¡Novedad en el armario!",
  verrou:"Versión completa", verrou_aide:"Este tema forma parte de la versión completa.",
  peu_de_mots:"Aún no hay suficientes palabras en este tema para este idioma.", sans_voix:"Aún no hay voz para esta palabra.",
  apropos:"Acerca de", apropos_texte:"Ami des mots es un juego para aprender y repasar palabras con imágenes, en 16 idiomas. Es un juego: no cura nada y no sustituye a ningún profesional. No se envía nada: tu progreso se queda en este dispositivo, sin cuenta y sin publicidad.",
  effacer_progres:"Borrar mi progreso", confirmer:"Toca otra vez para confirmar"
},
it:{
  accroche:"Parole in immagini, e un gufo per giocare.",
  je_parle:"Parlo", j_apprends:"Imparo", jouer:"Gioca", plumes:"piume",
  serie:n => n > 1 ? `${n} giorni di fila` : `1 giorno`, objectif:"Obiettivo di oggi: una partita", objectif_fait:"Obiettivo di oggi raggiunto ✓",
  th_animaux:"Animali", th_manger:"A tavola", th_maison:"La casa", th_habits:"Vestiti", th_nature:"Natura", th_ville:"In città", th_musique:"Musica e festa", th_atelier:"Laboratorio e scienze",
  j_decouvrir:"Scoprire", j_ecoute:"Ascolta e trova", j_quel_mot:"Quale parola?", j_memoire:"Memoria", j_lettres:"Lettere in disordine",
  a_decouvrir:"Guarda, ascolta, gira la carta.", a_ecoute:"Ascolta, poi tocca l'immagine giusta.", a_quel_mot:"Come si chiama questa immagine?", a_memoire:"Trova ogni immagine e la sua parola.", a_lettres:"Rimetti le lettere in ordine.",
  bravo:["Bravo!", "Ottimo!", "Sì, è giusto!"], rate:"Non proprio. Riprova!", c_etait:m => `Era: ${m}`,
  fin_titre:"Partita finita!", fin_plumes:n => `+${n} piume`, rejouer:"Rigioca", autre_jeu:"Altro gioco", themes:"Temi",
  suivant:"Avanti", ecouter:"Ascolta", retour:"Indietro", effacer:"Cancella", retourner:"Tocca la carta per girarla.",
  vestiaire:"Il guardaroba di Ami", acc_echarpe:"Sciarpa", acc_lunettes:"Occhiali", acc_noeud:"Papillon", acc_chapeau:"Cappello", acc_couronne:"Corona",
  a_partir:n => `Con ${n} piume`, porte:"Ami lo indossa", mettre:"Mettiglielo", enlever:"Toglieglielo", nouveau:"Novità nel guardaroba!",
  verrou:"Versione completa", verrou_aide:"Questo tema fa parte della versione completa.",
  peu_de_mots:"Non ci sono ancora abbastanza parole in questo tema per questa lingua.", sans_voix:"Ancora nessuna voce per questa parola.",
  apropos:"Informazioni", apropos_texte:"Ami des mots è un gioco per imparare e ripassare parole con le immagini, in 16 lingue. È un gioco: non cura niente e non sostituisce nessun professionista. Non viene inviato niente: i tuoi progressi restano su questo dispositivo, senza account e senza pubblicità.",
  effacer_progres:"Cancella i miei progressi", confirmer:"Tocca di nuovo per confermare"
},
pt:{
  accroche:"Palavras em imagens, e um mocho para brincar.",
  je_parle:"Falo", j_apprends:"Aprendo", jouer:"Jogar", plumes:"penas",
  serie:n => n > 1 ? `${n} dias seguidos` : `1 dia`, objectif:"Objetivo de hoje: um jogo", objectif_fait:"Objetivo de hoje cumprido ✓",
  th_animaux:"Animais", th_manger:"À mesa", th_maison:"A casa", th_habits:"Roupa", th_nature:"Natureza", th_ville:"Na cidade", th_musique:"Música e festa", th_atelier:"Oficina e ciências",
  j_decouvrir:"Descobrir", j_ecoute:"Ouve e encontra", j_quel_mot:"Que palavra?", j_memoire:"Memória", j_lettres:"Letras baralhadas",
  a_decouvrir:"Olha, ouve, vira a carta.", a_ecoute:"Ouve e toca na imagem certa.", a_quel_mot:"Como se chama esta imagem?", a_memoire:"Encontra cada imagem e a sua palavra.", a_lettres:"Põe as letras por ordem.",
  bravo:["Boa!", "Fantástico!", "Sim, é isso!"], rate:"Ainda não. Tenta outra vez!", c_etait:m => `Era: ${m}`,
  fin_titre:"Jogo terminado!", fin_plumes:n => `+${n} penas`, rejouer:"Jogar outra vez", autre_jeu:"Outro jogo", themes:"Temas",
  suivant:"Seguinte", ecouter:"Ouvir", retour:"Voltar", effacer:"Apagar", retourner:"Toca na carta para a virar.",
  vestiaire:"O guarda-roupa do Ami", acc_echarpe:"Cachecol", acc_lunettes:"Óculos", acc_noeud:"Laço", acc_chapeau:"Chapéu", acc_couronne:"Coroa",
  a_partir:n => `Com ${n} penas`, porte:"O Ami está a usá-lo", mettre:"Vestir-lho", enlever:"Tirar-lho", nouveau:"Novidade no guarda-roupa!",
  verrou:"Versão completa", verrou_aide:"Este tema faz parte da versão completa.",
  peu_de_mots:"Ainda não há palavras suficientes neste tema para esta língua.", sans_voix:"Ainda não há voz para esta palavra.",
  apropos:"Sobre", apropos_texte:"Ami des mots é um jogo para aprender e rever palavras com imagens, em 16 línguas. É um jogo: não trata nada e não substitui nenhum profissional. Nada é enviado: o teu progresso fica neste aparelho, sem conta e sem publicidade.",
  effacer_progres:"Apagar o meu progresso", confirmer:"Toca outra vez para confirmar"
},
de:{
  accroche:"Wörter in Bildern – und eine Eule zum Spielen.",
  je_parle:"Ich spreche", j_apprends:"Ich lerne", jouer:"Spielen", plumes:"Federn",
  serie:n => n > 1 ? `${n} Tage in Folge` : `1 Tag`, objectif:"Ziel für heute: ein Spiel", objectif_fait:"Ziel für heute erreicht ✓",
  th_animaux:"Tiere", th_manger:"Bei Tisch", th_maison:"Das Haus", th_habits:"Kleidung", th_nature:"Natur", th_ville:"In der Stadt", th_musique:"Musik und Feste", th_atelier:"Werkstatt und Wissenschaft",
  j_decouvrir:"Entdecken", j_ecoute:"Hören und finden", j_quel_mot:"Welches Wort?", j_memoire:"Memory", j_lettres:"Buchstabensalat",
  a_decouvrir:"Schau, hör zu, dreh die Karte um.", a_ecoute:"Hör zu und tippe auf das richtige Bild.", a_quel_mot:"Wie heißt dieses Bild?", a_memoire:"Finde zu jedem Bild sein Wort.", a_lettres:"Bring die Buchstaben in die richtige Reihenfolge.",
  bravo:["Bravo!", "Super!", "Ja, genau!"], rate:"Nicht ganz. Versuch es noch einmal!", c_etait:m => `Es war: ${m}`,
  fin_titre:"Spiel beendet!", fin_plumes:n => `+${n} Federn`, rejouer:"Noch einmal", autre_jeu:"Anderes Spiel", themes:"Themen",
  suivant:"Weiter", ecouter:"Anhören", retour:"Zurück", effacer:"Löschen", retourner:"Tippe auf die Karte, um sie umzudrehen.",
  vestiaire:"Amis Kleiderschrank", acc_echarpe:"Schal", acc_lunettes:"Brille", acc_noeud:"Fliege", acc_chapeau:"Hut", acc_couronne:"Krone",
  a_partir:n => `Ab ${n} Federn`, porte:"Ami trägt es", mettre:"Anziehen", enlever:"Ausziehen", nouveau:"Neu im Kleiderschrank!",
  verrou:"Vollversion", verrou_aide:"Dieses Thema gehört zur Vollversion.",
  peu_de_mots:"Für diese Sprache gibt es in diesem Thema noch nicht genug Wörter.", sans_voix:"Für dieses Wort gibt es noch keine Stimme.",
  apropos:"Über", apropos_texte:"Ami des mots ist ein Spiel, um Wörter mit Bildern zu lernen und zu wiederholen, in 16 Sprachen. Es ist ein Spiel: Es heilt nichts und ersetzt keine Fachkraft. Nichts wird gesendet: Dein Fortschritt bleibt auf diesem Gerät, ohne Konto und ohne Werbung.",
  effacer_progres:"Meinen Fortschritt löschen", confirmer:"Zum Bestätigen noch einmal tippen"
},
ar:{
  accroche:"كلمات بالصور، وبومة نلعب معها.",
  je_parle:"أتكلم", j_apprends:"أتعلّم", jouer:"العب", plumes:"ريشة",
  serie:n => n > 1 ? `${n} أيام متتالية` : `يوم واحد`, objectif:"هدف اليوم: لعبة واحدة", objectif_fait:"تحقّق هدف اليوم ✓",
  th_animaux:"الحيوانات", th_manger:"على المائدة", th_maison:"البيت", th_habits:"الملابس", th_nature:"الطبيعة", th_ville:"في المدينة", th_musique:"الموسيقى والاحتفال", th_atelier:"الورشة والعلوم",
  j_decouvrir:"اكتشف", j_ecoute:"استمع وجِد", j_quel_mot:"ما الكلمة؟", j_memoire:"الذاكرة", j_lettres:"حروف مبعثرة",
  a_decouvrir:"انظر، استمع، اقلب البطاقة.", a_ecoute:"استمع، ثم اضغط على الصورة الصحيحة.", a_quel_mot:"ما اسم هذه الصورة؟", a_memoire:"جِد كل صورة وكلمتها.", a_lettres:"رتّب الحروف.",
  bravo:["أحسنت!", "رائع!", "نعم، هذا صحيح!"], rate:"ليس تمامًا. حاول مرة أخرى!", c_etait:m => `كانت: ${m}`,
  fin_titre:"انتهت اللعبة!", fin_plumes:n => `+${n} ريشة`, rejouer:"العب مجددًا", autre_jeu:"لعبة أخرى", themes:"المواضيع",
  suivant:"التالي", ecouter:"استمع", retour:"رجوع", effacer:"مسح", retourner:"اضغط على البطاقة لقلبها.",
  vestiaire:"خزانة آمي", acc_echarpe:"وشاح", acc_lunettes:"نظارة", acc_noeud:"ربطة عنق فراشة", acc_chapeau:"قبعة", acc_couronne:"تاج",
  a_partir:n => `عند ${n} ريشة`, porte:"آمي يرتديه", mettre:"ألبسه إياه", enlever:"انزعه عنه", nouveau:"جديد في الخزانة!",
  verrou:"النسخة الكاملة", verrou_aide:"هذا الموضوع جزء من النسخة الكاملة.",
  peu_de_mots:"لا توجد بعد كلمات كافية في هذا الموضوع لهذه اللغة.", sans_voix:"لا يوجد صوت لهذه الكلمة بعد.",
  apropos:"حول اللعبة", apropos_texte:"«Ami des mots» لعبة لتعلّم الكلمات ومراجعتها بالصور، في 16 لغة. إنها لعبة: لا تعالج شيئًا ولا تحلّ محلّ أي مختص. لا يُرسل أي شيء: يبقى تقدّمك على هذا الجهاز، بلا حساب ولا إعلانات.",
  effacer_progres:"محو تقدّمي", confirmer:"اضغط مرة أخرى للتأكيد"
},
tr:{
  accroche:"Resimlerle kelimeler ve oynamak için bir baykuş.",
  je_parle:"Konuştuğum dil", j_apprends:"Öğrendiğim dil", jouer:"Oyna", plumes:"tüy",
  serie:n => n > 1 ? `Üst üste ${n} gün` : `1 gün`, objectif:"Bugünün hedefi: bir oyun", objectif_fait:"Bugünün hedefine ulaşıldı ✓",
  th_animaux:"Hayvanlar", th_manger:"Sofrada", th_maison:"Ev", th_habits:"Giysiler", th_nature:"Doğa", th_ville:"Şehirde", th_musique:"Müzik ve eğlence", th_atelier:"Atölye ve bilim",
  j_decouvrir:"Keşfet", j_ecoute:"Dinle ve bul", j_quel_mot:"Hangi kelime?", j_memoire:"Hafıza", j_lettres:"Karışık harfler",
  a_decouvrir:"Bak, dinle, kartı çevir.", a_ecoute:"Dinle, sonra doğru resme dokun.", a_quel_mot:"Bu resmin adı ne?", a_memoire:"Her resmi ve kelimesini bul.", a_lettres:"Harfleri sıraya koy.",
  bravo:["Aferin!", "Harika!", "Evet, doğru!"], rate:"Tam değil. Bir daha dene!", c_etait:m => `Doğrusu: ${m}`,
  fin_titre:"Oyun bitti!", fin_plumes:n => `+${n} tüy`, rejouer:"Tekrar oyna", autre_jeu:"Başka oyun", themes:"Konular",
  suivant:"Sonraki", ecouter:"Dinle", retour:"Geri", effacer:"Sil", retourner:"Çevirmek için karta dokun.",
  vestiaire:"Ami'nin dolabı", acc_echarpe:"Atkı", acc_lunettes:"Gözlük", acc_noeud:"Papyon", acc_chapeau:"Şapka", acc_couronne:"Taç",
  a_partir:n => `${n} tüyde`, porte:"Ami takıyor", mettre:"Tak", enlever:"Çıkar", nouveau:"Dolapta yeni bir şey var!",
  verrou:"Tam sürüm", verrou_aide:"Bu konu tam sürümün bir parçası.",
  peu_de_mots:"Bu konuda bu dil için henüz yeterli kelime yok.", sans_voix:"Bu kelimenin henüz sesi yok.",
  apropos:"Hakkında", apropos_texte:"Ami des mots, 16 dilde resimlerle kelime öğrenmek ve tekrar etmek için bir oyundur. Bu bir oyundur: hiçbir şeyi tedavi etmez ve hiçbir uzmanın yerini tutmaz. Hiçbir şey gönderilmez: ilerlemen bu cihazda kalır, hesap ve reklam yoktur.",
  effacer_progres:"İlerlememi sil", confirmer:"Onaylamak için tekrar dokun"
},
pl:{
  accroche:"Słowa w obrazkach i sowa do zabawy.",
  je_parle:"Mój język", j_apprends:"Uczę się", jouer:"Graj", plumes:"piórek",
  serie:n => n > 1 ? `Dni z rzędu: ${n}` : `1 dzień`, objectif:"Cel na dziś: jedna gra", objectif_fait:"Cel na dziś osiągnięty ✓",
  th_animaux:"Zwierzęta", th_manger:"Przy stole", th_maison:"Dom", th_habits:"Ubrania", th_nature:"Przyroda", th_ville:"W mieście", th_musique:"Muzyka i zabawa", th_atelier:"Warsztat i nauka",
  j_decouvrir:"Odkrywaj", j_ecoute:"Słuchaj i znajdź", j_quel_mot:"Jakie słowo?", j_memoire:"Memory", j_lettres:"Pomieszane litery",
  a_decouvrir:"Patrz, słuchaj, odwróć kartę.", a_ecoute:"Posłuchaj i dotknij właściwego obrazka.", a_quel_mot:"Jak nazywa się ten obrazek?", a_memoire:"Połącz każdy obrazek z jego słowem.", a_lettres:"Ułóż litery we właściwej kolejności.",
  bravo:["Brawo!", "Super!", "Tak, właśnie tak!"], rate:"Nie całkiem. Spróbuj jeszcze raz!", c_etait:m => `To było: ${m}`,
  fin_titre:"Koniec gry!", fin_plumes:n => `Piórka: +${n}`, rejouer:"Zagraj jeszcze raz", autre_jeu:"Inna gra", themes:"Tematy",
  suivant:"Dalej", ecouter:"Posłuchaj", retour:"Wróć", effacer:"Wyczyść", retourner:"Dotknij karty, aby ją odwrócić.",
  vestiaire:"Szafa Amiego", acc_echarpe:"Szalik", acc_lunettes:"Okulary", acc_noeud:"Muszka", acc_chapeau:"Kapelusz", acc_couronne:"Korona",
  a_partir:n => `Od ${n} piórek`, porte:"Ami to nosi", mettre:"Załóż mu", enlever:"Zdejmij mu", nouveau:"Nowość w szafie!",
  verrou:"Pełna wersja", verrou_aide:"Ten temat należy do pełnej wersji.",
  peu_de_mots:"W tym temacie nie ma jeszcze dość słów w tym języku.", sans_voix:"To słowo nie ma jeszcze nagrania.",
  apropos:"O grze", apropos_texte:"Ami des mots to gra do nauki i powtarzania słów z obrazkami, w 16 językach. To gra: niczego nie leczy i nie zastępuje żadnego specjalisty. Nic nie jest wysyłane: twoje postępy zostają na tym urządzeniu, bez konta i bez reklam.",
  effacer_progres:"Usuń moje postępy", confirmer:"Dotknij jeszcze raz, aby potwierdzić"
},
uk:{
  accroche:"Слова в картинках і сова, з якою можна гратися.",
  je_parle:"Я розмовляю", j_apprends:"Я вивчаю", jouer:"Грати", plumes:"пір'їн",
  serie:n => n > 1 ? `Днів поспіль: ${n}` : `1 день`, objectif:"Мета на сьогодні: одна гра", objectif_fait:"Мету на сьогодні досягнуто ✓",
  th_animaux:"Тварини", th_manger:"За столом", th_maison:"Дім", th_habits:"Одяг", th_nature:"Природа", th_ville:"У місті", th_musique:"Музика і свято", th_atelier:"Майстерня і наука",
  j_decouvrir:"Відкривай", j_ecoute:"Слухай і знайди", j_quel_mot:"Яке слово?", j_memoire:"Пам'ять", j_lettres:"Переплутані літери",
  a_decouvrir:"Дивись, слухай, переверни картку.", a_ecoute:"Послухай і торкнися правильної картинки.", a_quel_mot:"Як називається ця картинка?", a_memoire:"Знайди для кожної картинки її слово.", a_lettres:"Постав літери по порядку.",
  bravo:["Браво!", "Чудово!", "Так, правильно!"], rate:"Не зовсім. Спробуй ще раз!", c_etait:m => `Це було: ${m}`,
  fin_titre:"Гру завершено!", fin_plumes:n => `Пір'їн: +${n}`, rejouer:"Грати ще", autre_jeu:"Інша гра", themes:"Теми",
  suivant:"Далі", ecouter:"Слухати", retour:"Назад", effacer:"Стерти", retourner:"Торкнися картки, щоб перевернути її.",
  vestiaire:"Шафа Амі", acc_echarpe:"Шарф", acc_lunettes:"Окуляри", acc_noeud:"Метелик", acc_chapeau:"Капелюх", acc_couronne:"Корона",
  a_partir:n => `Від ${n} пір'їн`, porte:"Амі це носить", mettre:"Вдягти", enlever:"Зняти", nouveau:"Новинка в шафі!",
  verrou:"Повна версія", verrou_aide:"Ця тема входить до повної версії.",
  peu_de_mots:"У цій темі ще замало слів цією мовою.", sans_voix:"Для цього слова ще немає голосу.",
  apropos:"Про гру", apropos_texte:"Ami des mots — гра, щоб вивчати й повторювати слова з картинками, 16 мовами. Це гра: вона нічого не лікує і не замінює жодного фахівця. Нічого не надсилається: твій поступ залишається на цьому пристрої, без облікового запису й без реклами.",
  effacer_progres:"Стерти мій поступ", confirmer:"Торкнися ще раз, щоб підтвердити"
},
ja:{
  accroche:"絵で覚えることばと、いっしょに遊ぶフクロウ。",
  je_parle:"わたしの言語", j_apprends:"学ぶ言語", jouer:"あそぶ", plumes:"はね",
  serie:n => n > 1 ? `${n}日れんぞく` : `1日`, objectif:"きょうの目標：1回あそぶ", objectif_fait:"きょうの目標たっせい ✓",
  th_animaux:"どうぶつ", th_manger:"食たく", th_maison:"いえ", th_habits:"ふく", th_nature:"しぜん", th_ville:"まち", th_musique:"音楽とおまつり", th_atelier:"工作と科学",
  j_decouvrir:"見てみる", j_ecoute:"聞いてさがす", j_quel_mot:"どのことば？", j_memoire:"しんけいすいじゃく", j_lettres:"もじならべ",
  a_decouvrir:"見て、聞いて、カードをめくろう。", a_ecoute:"聞いて、正しい絵を押そう。", a_quel_mot:"この絵の名前は？", a_memoire:"絵とことばの組をさがそう。", a_lettres:"もじを正しくならべよう。",
  bravo:["すごい！", "よくできました！", "そう、正解！"], rate:"おしい！もう一度！", c_etait:m => `正解は：${m}`,
  fin_titre:"おしまい！", fin_plumes:n => `はね +${n}`, rejouer:"もう一度", autre_jeu:"ほかのゲーム", themes:"テーマ",
  suivant:"つぎへ", ecouter:"聞く", retour:"もどる", effacer:"けす", retourner:"カードを押すとめくれます。",
  vestiaire:"アミのクローゼット", acc_echarpe:"マフラー", acc_lunettes:"めがね", acc_noeud:"ちょうネクタイ", acc_chapeau:"ぼうし", acc_couronne:"かんむり",
  a_partir:n => `はね${n}まいで`, porte:"アミがつけています", mettre:"つける", enlever:"はずす", nouveau:"クローゼットに新しいものが！",
  verrou:"完全版", verrou_aide:"このテーマは完全版に入っています。",
  peu_de_mots:"この言語では、このテーマのことばがまだ足りません。", sans_voix:"このことばの音声はまだありません。",
  apropos:"このゲームについて", apropos_texte:"Ami des mots は、16の言語で、絵を見ながらことばを覚えたり復習したりするゲームです。ゲームなので、治療はせず、専門家の代わりにもなりません。何も送信されません。記録はこの端末だけに残り、アカウントも広告もありません。",
  effacer_progres:"記録をけす", confirmer:"もう一度押すと確定します"
}
};

// ── v2 : joueurs, défi, révision, carnet, trophées, Vrai ou faux, Plus ──
(function(){
const V2 = {
fr:{
  bonjour:n => `Bonjour ${n} !`, changer_joueur:"Changer de joueur", qui_joue:"Qui joue ?", ajouter_joueur:"Ajouter un joueur", modifier_joueur:"Modifier le joueur",
  prenom:"Prénom", couleur:"Couleur d'Ami", valider:"Valider", supprimer_joueur:"Supprimer ce joueur", joueurs:"Joueurs",
  defi:"Défi du jour", defi_fait:"Défi du jour réussi !", revoir:"À revoir", revoir_rien:"Rien à revoir aujourd'hui. Jouez pour découvrir de nouveaux mots !",
  carnet:"Mon carnet", carnet_aide:"Touchez un mot pour l'écouter.", carnet_vide:"Votre carnet est vide. Jouez pour le remplir !",
  maitrise:n => `${n} mots bien connus`, connus:(a, b) => `${a} mots bien connus sur ${b}`,
  j_vrai_faux:"Vrai ou faux ?", a_vrai_faux:"Ce mot va-t-il avec l'image ?", vrai:"Vrai", faux:"Faux",
  trophees:"Trophées", tr_premiere:"Première partie", tr_serie3:"3 jours de suite", tr_serie7:"7 jours de suite", tr_mots25:"25 mots bien connus", tr_mots100:"100 mots bien connus", tr_theme:"Un thème parfait", tr_defi5:"5 défis du jour", nouveau_trophee:"Nouveau trophée",
  reglages:"Réglages", son:"Bruitages", oui:"Oui", non:"Non",
  plus:"Ami des mots Plus", plus_court:"tous les thèmes et tous les jeux", plus_badge:"Plus", plus_titre:"Tout Ami des mots, pour toute la famille.",
  plus_avantages:["Les 8 thèmes, tous les mots", "Les 6 jeux, dont Mémoire et Lettres en vrac", "Jusqu'à 6 joueurs sur l'appareil", "Les nouveaux mots et jeux à venir"],
  plus_prix:p => `${p} par mois`, sans_engagement:"Sans engagement, résiliable à tout moment.", s_abonner:"S'abonner", bientot:"Bientôt disponible",
  gratuit_reste:"La version gratuite reste gratuite : 3 thèmes, 3 jeux, le défi du jour et la révision.",
  deja_abonne:"J'ai déjà un abonnement", code_abo:"Code d'abonnement", code_aide:"Notez ce code : il permet de retrouver l'abonnement sur un autre appareil.", verifier:"Vérifier",
  abo_actif:d => `Abonnement actif${d ? ` (jusqu'au ${d})` : ''}. Merci !`, abo_inconnu:"Code introuvable ou abonnement terminé.", hors_ligne:"Vérification impossible pour l'instant. Réessayez plus tard.", gerer_abo:"Gérer ou résilier l'abonnement", decouvrir_plus:"Découvrir Ami des mots Plus",
  apropos_texte:"Ami des mots est un jeu pour apprendre et réviser des mots en images, dans 16 langues. C'est un jeu : il ne soigne rien et ne remplace aucun professionnel. Sans compte et sans publicité : vos progrès restent sur cet appareil. Pour l'abonnement, seul un code anonyme est vérifié ; le paiement est géré par Stripe."
},
en:{
  bonjour:n => `Hello ${n}!`, changer_joueur:"Switch player", qui_joue:"Who's playing?", ajouter_joueur:"Add a player", modifier_joueur:"Edit player",
  prenom:"First name", couleur:"Ami's colour", valider:"OK", supprimer_joueur:"Delete this player", joueurs:"Players",
  defi:"Daily challenge", defi_fait:"Daily challenge done!", revoir:"Review", revoir_rien:"Nothing to review today. Play to discover new words!",
  carnet:"My notebook", carnet_aide:"Tap a word to hear it.", carnet_vide:"Your notebook is empty. Play to fill it!",
  maitrise:n => `${n} words known well`, connus:(a, b) => `${a} of ${b} words known well`,
  j_vrai_faux:"True or false?", a_vrai_faux:"Does this word match the picture?", vrai:"True", faux:"False",
  trophees:"Trophies", tr_premiere:"First game", tr_serie3:"3 days in a row", tr_serie7:"7 days in a row", tr_mots25:"25 words known well", tr_mots100:"100 words known well", tr_theme:"A perfect theme", tr_defi5:"5 daily challenges", nouveau_trophee:"New trophy",
  reglages:"Settings", son:"Sound effects", oui:"On", non:"Off",
  plus:"Ami des mots Plus", plus_court:"every theme and every game", plus_badge:"Plus", plus_titre:"All of Ami des mots, for the whole family.",
  plus_avantages:["All 8 themes, every word", "All 6 games, including Memory and Jumbled letters", "Up to 6 players on this device", "New words and games as they come"],
  plus_prix:p => `${p} a month`, sans_engagement:"No commitment, cancel at any time.", s_abonner:"Subscribe", bientot:"Coming soon",
  gratuit_reste:"The free version stays free: 3 themes, 3 games, the daily challenge and review.",
  deja_abonne:"I already have a subscription", code_abo:"Subscription code", code_aide:"Write this code down: it restores the subscription on another device.", verifier:"Check",
  abo_actif:d => `Subscription active${d ? ` (until ${d})` : ''}. Thank you!`, abo_inconnu:"Code not found or subscription ended.", hors_ligne:"Can't check right now. Please try again later.", gerer_abo:"Manage or cancel the subscription", decouvrir_plus:"Discover Ami des mots Plus",
  apropos_texte:"Ami des mots is a game for learning and reviewing words with pictures, in 16 languages. It is a game: it doesn't treat anything and doesn't replace any professional. No account and no ads: your progress stays on this device. For the subscription, only an anonymous code is checked; payment is handled by Stripe."
},
es:{
  bonjour:n => `¡Hola, ${n}!`, changer_joueur:"Cambiar de jugador", qui_joue:"¿Quién juega?", ajouter_joueur:"Añadir un jugador", modifier_joueur:"Editar jugador",
  prenom:"Nombre", couleur:"Color de Ami", valider:"Aceptar", supprimer_joueur:"Eliminar este jugador", joueurs:"Jugadores",
  defi:"Reto del día", defi_fait:"¡Reto del día superado!", revoir:"Repasar", revoir_rien:"Nada que repasar hoy. ¡Juega para descubrir palabras nuevas!",
  carnet:"Mi cuaderno", carnet_aide:"Toca una palabra para escucharla.", carnet_vide:"Tu cuaderno está vacío. ¡Juega para llenarlo!",
  maitrise:n => `${n} palabras bien sabidas`, connus:(a, b) => `${a} de ${b} palabras bien sabidas`,
  j_vrai_faux:"¿Verdadero o falso?", a_vrai_faux:"¿Esta palabra va con la imagen?", vrai:"Verdadero", faux:"Falso",
  trophees:"Trofeos", tr_premiere:"Primera partida", tr_serie3:"3 días seguidos", tr_serie7:"7 días seguidos", tr_mots25:"25 palabras bien sabidas", tr_mots100:"100 palabras bien sabidas", tr_theme:"Un tema perfecto", tr_defi5:"5 retos del día", nouveau_trophee:"Nuevo trofeo",
  reglages:"Ajustes", son:"Efectos de sonido", oui:"Sí", non:"No",
  plus:"Ami des mots Plus", plus_court:"todos los temas y todos los juegos", plus_badge:"Plus", plus_titre:"Todo Ami des mots, para toda la familia.",
  plus_avantages:["Los 8 temas, todas las palabras", "Los 6 juegos, incluidos Memoria y Letras revueltas", "Hasta 6 jugadores en el dispositivo", "Las nuevas palabras y juegos que lleguen"],
  plus_prix:p => `${p} al mes`, sans_engagement:"Sin permanencia, cancela cuando quieras.", s_abonner:"Suscribirse", bientot:"Próximamente",
  gratuit_reste:"La versión gratuita sigue siendo gratuita: 3 temas, 3 juegos, el reto del día y el repaso.",
  deja_abonne:"Ya tengo una suscripción", code_abo:"Código de suscripción", code_aide:"Apunta este código: sirve para recuperar la suscripción en otro dispositivo.", verifier:"Comprobar",
  abo_actif:d => `Suscripción activa${d ? ` (hasta el ${d})` : ''}. ¡Gracias!`, abo_inconnu:"Código no encontrado o suscripción terminada.", hors_ligne:"No se puede comprobar ahora. Inténtalo más tarde.", gerer_abo:"Gestionar o cancelar la suscripción", decouvrir_plus:"Descubrir Ami des mots Plus",
  apropos_texte:"Ami des mots es un juego para aprender y repasar palabras con imágenes, en 16 idiomas. Es un juego: no cura nada ni sustituye a ningún profesional. Sin cuenta y sin publicidad: tu progreso se queda en este dispositivo. Para la suscripción solo se comprueba un código anónimo; el pago lo gestiona Stripe."
},
it:{
  bonjour:n => `Ciao ${n}!`, changer_joueur:"Cambia giocatore", qui_joue:"Chi gioca?", ajouter_joueur:"Aggiungi un giocatore", modifier_joueur:"Modifica giocatore",
  prenom:"Nome", couleur:"Colore di Ami", valider:"Conferma", supprimer_joueur:"Elimina questo giocatore", joueurs:"Giocatori",
  defi:"Sfida del giorno", defi_fait:"Sfida del giorno superata!", revoir:"Da ripassare", revoir_rien:"Niente da ripassare oggi. Gioca per scoprire nuove parole!",
  carnet:"Il mio quaderno", carnet_aide:"Tocca una parola per ascoltarla.", carnet_vide:"Il tuo quaderno è vuoto. Gioca per riempirlo!",
  maitrise:n => `${n} parole ben conosciute`, connus:(a, b) => `${a} parole su ${b} ben conosciute`,
  j_vrai_faux:"Vero o falso?", a_vrai_faux:"Questa parola va con l'immagine?", vrai:"Vero", faux:"Falso",
  trophees:"Trofei", tr_premiere:"Prima partita", tr_serie3:"3 giorni di fila", tr_serie7:"7 giorni di fila", tr_mots25:"25 parole ben conosciute", tr_mots100:"100 parole ben conosciute", tr_theme:"Un tema perfetto", tr_defi5:"5 sfide del giorno", nouveau_trophee:"Nuovo trofeo",
  reglages:"Impostazioni", son:"Effetti sonori", oui:"Sì", non:"No",
  plus:"Ami des mots Plus", plus_court:"tutti i temi e tutti i giochi", plus_badge:"Plus", plus_titre:"Tutto Ami des mots, per tutta la famiglia.",
  plus_avantages:["Tutti gli 8 temi, tutte le parole", "Tutti i 6 giochi, compresi Memoria e Lettere in disordine", "Fino a 6 giocatori sul dispositivo", "Le nuove parole e i nuovi giochi in arrivo"],
  plus_prix:p => `${p} al mese`, sans_engagement:"Senza vincoli, disdici quando vuoi.", s_abonner:"Abbonati", bientot:"Presto disponibile",
  gratuit_reste:"La versione gratuita resta gratuita: 3 temi, 3 giochi, la sfida del giorno e il ripasso.",
  deja_abonne:"Ho già un abbonamento", code_abo:"Codice di abbonamento", code_aide:"Annota questo codice: serve a ritrovare l'abbonamento su un altro dispositivo.", verifier:"Verifica",
  abo_actif:d => `Abbonamento attivo${d ? ` (fino al ${d})` : ''}. Grazie!`, abo_inconnu:"Codice non trovato o abbonamento scaduto.", hors_ligne:"Impossibile verificare ora. Riprova più tardi.", gerer_abo:"Gestisci o disdici l'abbonamento", decouvrir_plus:"Scopri Ami des mots Plus",
  apropos_texte:"Ami des mots è un gioco per imparare e ripassare parole con le immagini, in 16 lingue. È un gioco: non cura nulla e non sostituisce alcun professionista. Senza account e senza pubblicità: i tuoi progressi restano su questo dispositivo. Per l'abbonamento si verifica solo un codice anonimo; il pagamento è gestito da Stripe."
},
pt:{
  bonjour:n => `Olá, ${n}!`, changer_joueur:"Mudar de jogador", qui_joue:"Quem joga?", ajouter_joueur:"Adicionar um jogador", modifier_joueur:"Editar jogador",
  prenom:"Nome", couleur:"Cor do Ami", valider:"Confirmar", supprimer_joueur:"Apagar este jogador", joueurs:"Jogadores",
  defi:"Desafio do dia", defi_fait:"Desafio do dia concluído!", revoir:"Rever", revoir_rien:"Nada para rever hoje. Jogue para descobrir palavras novas!",
  carnet:"O meu caderno", carnet_aide:"Toque numa palavra para a ouvir.", carnet_vide:"O seu caderno está vazio. Jogue para o preencher!",
  maitrise:n => `${n} palavras bem sabidas`, connus:(a, b) => `${a} de ${b} palavras bem sabidas`,
  j_vrai_faux:"Verdadeiro ou falso?", a_vrai_faux:"Esta palavra corresponde à imagem?", vrai:"Verdadeiro", faux:"Falso",
  trophees:"Troféus", tr_premiere:"Primeiro jogo", tr_serie3:"3 dias seguidos", tr_serie7:"7 dias seguidos", tr_mots25:"25 palavras bem sabidas", tr_mots100:"100 palavras bem sabidas", tr_theme:"Um tema perfeito", tr_defi5:"5 desafios do dia", nouveau_trophee:"Novo troféu",
  reglages:"Definições", son:"Efeitos sonoros", oui:"Sim", non:"Não",
  plus:"Ami des mots Plus", plus_court:"todos os temas e todos os jogos", plus_badge:"Plus", plus_titre:"Todo o Ami des mots, para toda a família.",
  plus_avantages:["Os 8 temas, todas as palavras", "Os 6 jogos, incluindo Memória e Letras baralhadas", "Até 6 jogadores no dispositivo", "As novas palavras e jogos que vierem"],
  plus_prix:p => `${p} por mês`, sans_engagement:"Sem fidelização, cancele quando quiser.", s_abonner:"Subscrever", bientot:"Brevemente",
  gratuit_reste:"A versão gratuita continua gratuita: 3 temas, 3 jogos, o desafio do dia e a revisão.",
  deja_abonne:"Já tenho uma subscrição", code_abo:"Código de subscrição", code_aide:"Guarde este código: permite recuperar a subscrição noutro dispositivo.", verifier:"Verificar",
  abo_actif:d => `Subscrição ativa${d ? ` (até ${d})` : ''}. Obrigado!`, abo_inconnu:"Código não encontrado ou subscrição terminada.", hors_ligne:"Não é possível verificar agora. Tente mais tarde.", gerer_abo:"Gerir ou cancelar a subscrição", decouvrir_plus:"Descobrir o Ami des mots Plus",
  apropos_texte:"Ami des mots é um jogo para aprender e rever palavras com imagens, em 16 línguas. É um jogo: não trata nada nem substitui nenhum profissional. Sem conta e sem publicidade: o seu progresso fica neste dispositivo. Para a subscrição só se verifica um código anónimo; o pagamento é gerido pela Stripe."
},
de:{
  bonjour:n => `Hallo ${n}!`, changer_joueur:"Spieler wechseln", qui_joue:"Wer spielt?", ajouter_joueur:"Spieler hinzufügen", modifier_joueur:"Spieler bearbeiten",
  prenom:"Vorname", couleur:"Amis Farbe", valider:"Bestätigen", supprimer_joueur:"Diesen Spieler löschen", joueurs:"Spieler",
  defi:"Tagesaufgabe", defi_fait:"Tagesaufgabe geschafft!", revoir:"Wiederholen", revoir_rien:"Heute gibt es nichts zu wiederholen. Spiel und entdecke neue Wörter!",
  carnet:"Mein Heft", carnet_aide:"Tippe auf ein Wort, um es zu hören.", carnet_vide:"Dein Heft ist leer. Spiel, um es zu füllen!",
  maitrise:n => `${n} Wörter gut gelernt`, connus:(a, b) => `${a} von ${b} Wörtern gut gelernt`,
  j_vrai_faux:"Richtig oder falsch?", a_vrai_faux:"Passt dieses Wort zum Bild?", vrai:"Richtig", faux:"Falsch",
  trophees:"Pokale", tr_premiere:"Erstes Spiel", tr_serie3:"3 Tage am Stück", tr_serie7:"7 Tage am Stück", tr_mots25:"25 Wörter gut gelernt", tr_mots100:"100 Wörter gut gelernt", tr_theme:"Ein perfektes Thema", tr_defi5:"5 Tagesaufgaben", nouveau_trophee:"Neuer Pokal",
  reglages:"Einstellungen", son:"Geräusche", oui:"An", non:"Aus",
  plus:"Ami des mots Plus", plus_court:"alle Themen und alle Spiele", plus_badge:"Plus", plus_titre:"Ganz Ami des mots, für die ganze Familie.",
  plus_avantages:["Alle 8 Themen, alle Wörter", "Alle 6 Spiele, auch Memory und Buchstabensalat", "Bis zu 6 Spieler auf dem Gerät", "Neue Wörter und Spiele, sobald sie kommen"],
  plus_prix:p => `${p} pro Monat`, sans_engagement:"Ohne Bindung, jederzeit kündbar.", s_abonner:"Abonnieren", bientot:"Bald verfügbar",
  gratuit_reste:"Die kostenlose Version bleibt kostenlos: 3 Themen, 3 Spiele, die Tagesaufgabe und das Wiederholen.",
  deja_abonne:"Ich habe schon ein Abo", code_abo:"Abo-Code", code_aide:"Notiere diesen Code: Damit findest du das Abo auf einem anderen Gerät wieder.", verifier:"Prüfen",
  abo_actif:d => `Abo aktiv${d ? ` (bis ${d})` : ''}. Danke!`, abo_inconnu:"Code nicht gefunden oder Abo beendet.", hors_ligne:"Prüfen gerade nicht möglich. Versuch es später noch einmal.", gerer_abo:"Abo verwalten oder kündigen", decouvrir_plus:"Ami des mots Plus entdecken",
  apropos_texte:"Ami des mots ist ein Spiel, um Wörter mit Bildern zu lernen und zu wiederholen, in 16 Sprachen. Es ist ein Spiel: Es behandelt nichts und ersetzt keine Fachkraft. Ohne Konto und ohne Werbung: Dein Fortschritt bleibt auf diesem Gerät. Für das Abo wird nur ein anonymer Code geprüft; die Zahlung läuft über Stripe."
},
ar:{
  bonjour:n => `مرحبًا ${n}!`, changer_joueur:"تغيير اللاعب", qui_joue:"من يلعب؟", ajouter_joueur:"إضافة لاعب", modifier_joueur:"تعديل اللاعب",
  prenom:"الاسم", couleur:"لون آمي", valider:"تأكيد", supprimer_joueur:"حذف هذا اللاعب", joueurs:"اللاعبون",
  defi:"تحدّي اليوم", defi_fait:"نجحت في تحدّي اليوم!", revoir:"للمراجعة", revoir_rien:"لا شيء للمراجعة اليوم. العب لتكتشف كلمات جديدة!",
  carnet:"دفتري", carnet_aide:"المس كلمة لتسمعها.", carnet_vide:"دفترك فارغ. العب لتملأه!",
  maitrise:n => `${n} كلمة معروفة جيدًا`, connus:(a, b) => `${a} من ${b} كلمة معروفة جيدًا`,
  j_vrai_faux:"صح أم خطأ؟", a_vrai_faux:"هل تناسب هذه الكلمة الصورة؟", vrai:"صح", faux:"خطأ",
  trophees:"الكؤوس", tr_premiere:"أول لعبة", tr_serie3:"3 أيام متتالية", tr_serie7:"7 أيام متتالية", tr_mots25:"25 كلمة معروفة جيدًا", tr_mots100:"100 كلمة معروفة جيدًا", tr_theme:"موضوع كامل", tr_defi5:"5 تحدّيات يومية", nouveau_trophee:"كأس جديدة",
  reglages:"الإعدادات", son:"المؤثرات الصوتية", oui:"نعم", non:"لا",
  plus:"Ami des mots Plus", plus_court:"كل المواضيع وكل الألعاب", plus_badge:"Plus", plus_titre:"كل Ami des mots، للعائلة كلها.",
  plus_avantages:["المواضيع الثمانية، كل الكلمات", "الألعاب الستّ، ومنها الذاكرة والحروف المبعثرة", "حتى 6 لاعبين على الجهاز", "الكلمات والألعاب الجديدة القادمة"],
  plus_prix:p => `${p} شهريًا`, sans_engagement:"بلا التزام، يمكن الإلغاء في أي وقت.", s_abonner:"اشترك", bientot:"قريبًا",
  gratuit_reste:"تبقى النسخة المجانية مجانية: 3 مواضيع و3 ألعاب وتحدّي اليوم والمراجعة.",
  deja_abonne:"لديّ اشتراك بالفعل", code_abo:"رمز الاشتراك", code_aide:"احتفظ بهذا الرمز: يسمح باستعادة الاشتراك على جهاز آخر.", verifier:"تحقّق",
  abo_actif:d => `الاشتراك فعّال${d ? ` (حتى ${d})` : ''}. شكرًا!`, abo_inconnu:"الرمز غير موجود أو انتهى الاشتراك.", hors_ligne:"لا يمكن التحقق الآن. حاول لاحقًا.", gerer_abo:"إدارة الاشتراك أو إلغاؤه", decouvrir_plus:"اكتشف Ami des mots Plus",
  apropos_texte:"Ami des mots لعبة لتعلّم الكلمات ومراجعتها بالصور، بـ16 لغة. إنها لعبة: لا تعالج شيئًا ولا تحلّ محل أي مختص. بلا حساب وبلا إعلانات: يبقى تقدّمك على هذا الجهاز. للاشتراك يُتحقَّق فقط من رمز مجهول الهوية، والدفع تديره Stripe."
},
tr:{
  bonjour:n => `Merhaba ${n}!`, changer_joueur:"Oyuncu değiştir", qui_joue:"Kim oynuyor?", ajouter_joueur:"Oyuncu ekle", modifier_joueur:"Oyuncuyu düzenle",
  prenom:"Ad", couleur:"Ami'nin rengi", valider:"Onayla", supprimer_joueur:"Bu oyuncuyu sil", joueurs:"Oyuncular",
  defi:"Günün görevi", defi_fait:"Günün görevi tamam!", revoir:"Tekrar", revoir_rien:"Bugün tekrar edilecek bir şey yok. Yeni kelimeler keşfetmek için oyna!",
  carnet:"Defterim", carnet_aide:"Dinlemek için bir kelimeye dokun.", carnet_vide:"Defterin boş. Doldurmak için oyna!",
  maitrise:n => `${n} kelime iyi biliniyor`, connus:(a, b) => `${b} kelimeden ${a} tanesi iyi biliniyor`,
  j_vrai_faux:"Doğru mu yanlış mı?", a_vrai_faux:"Bu kelime resme uyuyor mu?", vrai:"Doğru", faux:"Yanlış",
  trophees:"Kupalar", tr_premiere:"İlk oyun", tr_serie3:"Üst üste 3 gün", tr_serie7:"Üst üste 7 gün", tr_mots25:"25 kelime iyi biliniyor", tr_mots100:"100 kelime iyi biliniyor", tr_theme:"Kusursuz bir tema", tr_defi5:"5 günlük görev", nouveau_trophee:"Yeni kupa",
  reglages:"Ayarlar", son:"Ses efektleri", oui:"Açık", non:"Kapalı",
  plus:"Ami des mots Plus", plus_court:"tüm temalar ve tüm oyunlar", plus_badge:"Plus", plus_titre:"Ami des mots'un tamamı, bütün aile için.",
  plus_avantages:["8 temanın hepsi, tüm kelimeler", "6 oyunun hepsi, Hafıza ve Karışık harfler dahil", "Cihazda en fazla 6 oyuncu", "Gelecek yeni kelimeler ve oyunlar"],
  plus_prix:p => `Aylık ${p}`, sans_engagement:"Taahhüt yok, istediğin zaman iptal et.", s_abonner:"Abone ol", bientot:"Çok yakında",
  gratuit_reste:"Ücretsiz sürüm ücretsiz kalır: 3 tema, 3 oyun, günün görevi ve tekrar.",
  deja_abonne:"Zaten aboneliğim var", code_abo:"Abonelik kodu", code_aide:"Bu kodu not al: aboneliği başka bir cihazda geri getirmeye yarar.", verifier:"Kontrol et",
  abo_actif:d => `Abonelik etkin${d ? ` (${d} tarihine kadar)` : ''}. Teşekkürler!`, abo_inconnu:"Kod bulunamadı ya da abonelik sona erdi.", hors_ligne:"Şu anda kontrol edilemiyor. Daha sonra tekrar dene.", gerer_abo:"Aboneliği yönet veya iptal et", decouvrir_plus:"Ami des mots Plus'ı keşfet",
  apropos_texte:"Ami des mots, 16 dilde resimlerle kelime öğrenmek ve tekrar etmek için bir oyundur. Bu bir oyundur: hiçbir şeyi tedavi etmez ve hiçbir uzmanın yerini tutmaz. Hesap yok, reklam yok: ilerlemen bu cihazda kalır. Abonelik için yalnızca anonim bir kod kontrol edilir; ödemeyi Stripe yönetir."
},
pl:{
  bonjour:n => `Cześć, ${n}!`, changer_joueur:"Zmień gracza", qui_joue:"Kto gra?", ajouter_joueur:"Dodaj gracza", modifier_joueur:"Edytuj gracza",
  prenom:"Imię", couleur:"Kolor Amiego", valider:"Zatwierdź", supprimer_joueur:"Usuń tego gracza", joueurs:"Gracze",
  defi:"Wyzwanie dnia", defi_fait:"Wyzwanie dnia zaliczone!", revoir:"Do powtórki", revoir_rien:"Dziś nie ma nic do powtórki. Graj, aby poznać nowe słowa!",
  carnet:"Mój zeszyt", carnet_aide:"Dotknij słowa, aby je usłyszeć.", carnet_vide:"Twój zeszyt jest pusty. Graj, aby go wypełnić!",
  maitrise:n => `Dobrze znane słowa: ${n}`, connus:(a, b) => `Dobrze znane: ${a} z ${b} słów`,
  j_vrai_faux:"Prawda czy fałsz?", a_vrai_faux:"Czy to słowo pasuje do obrazka?", vrai:"Prawda", faux:"Fałsz",
  trophees:"Trofea", tr_premiere:"Pierwsza gra", tr_serie3:"3 dni z rzędu", tr_serie7:"7 dni z rzędu", tr_mots25:"25 dobrze znanych słów", tr_mots100:"100 dobrze znanych słów", tr_theme:"Idealny temat", tr_defi5:"5 wyzwań dnia", nouveau_trophee:"Nowe trofeum",
  reglages:"Ustawienia", son:"Efekty dźwiękowe", oui:"Wł.", non:"Wył.",
  plus:"Ami des mots Plus", plus_court:"wszystkie tematy i wszystkie gry", plus_badge:"Plus", plus_titre:"Całe Ami des mots dla całej rodziny.",
  plus_avantages:["Wszystkie 8 tematów, wszystkie słowa", "Wszystkie 6 gier, w tym Memory i Pomieszane litery", "Do 6 graczy na urządzeniu", "Nowe słowa i gry, gdy się pojawią"],
  plus_prix:p => `${p} miesięcznie`, sans_engagement:"Bez zobowiązań, rezygnacja w każdej chwili.", s_abonner:"Subskrybuj", bientot:"Wkrótce",
  gratuit_reste:"Wersja darmowa pozostaje darmowa: 3 tematy, 3 gry, wyzwanie dnia i powtórki.",
  deja_abonne:"Mam już subskrypcję", code_abo:"Kod subskrypcji", code_aide:"Zapisz ten kod: pozwala odzyskać subskrypcję na innym urządzeniu.", verifier:"Sprawdź",
  abo_actif:d => `Subskrypcja aktywna${d ? ` (do ${d})` : ''}. Dziękujemy!`, abo_inconnu:"Nie znaleziono kodu lub subskrypcja wygasła.", hors_ligne:"Nie można teraz sprawdzić. Spróbuj później.", gerer_abo:"Zarządzaj subskrypcją lub ją anuluj", decouvrir_plus:"Poznaj Ami des mots Plus",
  apropos_texte:"Ami des mots to gra do nauki i powtarzania słów z obrazkami, w 16 językach. To gra: niczego nie leczy i nie zastępuje żadnego specjalisty. Bez konta i bez reklam: twoje postępy zostają na tym urządzeniu. W przypadku subskrypcji sprawdzany jest tylko anonimowy kod; płatności obsługuje Stripe."
},
uk:{
  bonjour:n => `Привіт, ${n}!`, changer_joueur:"Змінити гравця", qui_joue:"Хто грає?", ajouter_joueur:"Додати гравця", modifier_joueur:"Змінити гравця",
  prenom:"Ім'я", couleur:"Колір Амі", valider:"Підтвердити", supprimer_joueur:"Видалити цього гравця", joueurs:"Гравці",
  defi:"Завдання дня", defi_fait:"Завдання дня виконано!", revoir:"Повторити", revoir_rien:"Сьогодні нічого повторювати. Грай, щоб відкрити нові слова!",
  carnet:"Мій зошит", carnet_aide:"Торкнися слова, щоб його почути.", carnet_vide:"Твій зошит порожній. Грай, щоб його заповнити!",
  maitrise:n => `Добре знаних слів: ${n}`, connus:(a, b) => `Добре знаних: ${a} з ${b}`,
  j_vrai_faux:"Правда чи ні?", a_vrai_faux:"Це слово пасує до малюнка?", vrai:"Правда", faux:"Ні",
  trophees:"Кубки", tr_premiere:"Перша гра", tr_serie3:"3 дні поспіль", tr_serie7:"7 днів поспіль", tr_mots25:"25 добре знаних слів", tr_mots100:"100 добре знаних слів", tr_theme:"Ідеальна тема", tr_defi5:"5 завдань дня", nouveau_trophee:"Новий кубок",
  reglages:"Налаштування", son:"Звукові ефекти", oui:"Увімк.", non:"Вимк.",
  plus:"Ami des mots Plus", plus_court:"усі теми й усі ігри", plus_badge:"Plus", plus_titre:"Увесь Ami des mots для всієї родини.",
  plus_avantages:["Усі 8 тем, усі слова", "Усі 6 ігор, зокрема «Пам'ять» і «Розкидані літери»", "До 6 гравців на пристрої", "Нові слова й ігри, щойно з'являться"],
  plus_prix:p => `${p} на місяць`, sans_engagement:"Без зобов'язань, скасування будь-коли.", s_abonner:"Підписатися", bientot:"Незабаром",
  gratuit_reste:"Безкоштовна версія залишається безкоштовною: 3 теми, 3 ігри, завдання дня й повторення.",
  deja_abonne:"У мене вже є підписка", code_abo:"Код підписки", code_aide:"Запиши цей код: він дає змогу відновити підписку на іншому пристрої.", verifier:"Перевірити",
  abo_actif:d => `Підписка активна${d ? ` (до ${d})` : ''}. Дякуємо!`, abo_inconnu:"Код не знайдено або підписка завершилася.", hors_ligne:"Зараз неможливо перевірити. Спробуй пізніше.", gerer_abo:"Керувати підпискою або скасувати її", decouvrir_plus:"Відкрити Ami des mots Plus",
  apropos_texte:"Ami des mots — це гра, щоб вивчати й повторювати слова з малюнками, 16 мовами. Це гра: вона нічого не лікує й не замінює жодного фахівця. Без облікового запису й без реклами: твій поступ залишається на цьому пристрої. Для підписки перевіряється лише анонімний код; оплатою займається Stripe."
},
ja:{
  bonjour:n => `こんにちは、${n}さん！`, changer_joueur:"プレイヤーを変える", qui_joue:"だれが遊ぶ？", ajouter_joueur:"プレイヤーを追加", modifier_joueur:"プレイヤーを編集",
  prenom:"名前", couleur:"アミの色", valider:"決定", supprimer_joueur:"このプレイヤーを削除", joueurs:"プレイヤー",
  defi:"今日のチャレンジ", defi_fait:"今日のチャレンジ達成！", revoir:"復習", revoir_rien:"今日は復習するものはありません。遊んで新しいことばを見つけよう！",
  carnet:"わたしのノート", carnet_aide:"ことばにタッチすると聞けます。", carnet_vide:"ノートはまだ空です。遊んでいっぱいにしよう！",
  maitrise:n => `よく覚えたことば：${n}`, connus:(a, b) => `${b}語中${a}語をよく覚えた`,
  j_vrai_faux:"○か×か？", a_vrai_faux:"このことばは絵と合っている？", vrai:"○ 合っている", faux:"× ちがう",
  trophees:"トロフィー", tr_premiere:"はじめてのゲーム", tr_serie3:"3日連続", tr_serie7:"7日連続", tr_mots25:"25語をよく覚えた", tr_mots100:"100語をよく覚えた", tr_theme:"パーフェクトなテーマ", tr_defi5:"今日のチャレンジ5回", nouveau_trophee:"新しいトロフィー",
  reglages:"設定", son:"効果音", oui:"オン", non:"オフ",
  plus:"Ami des mots Plus", plus_court:"すべてのテーマとすべてのゲーム", plus_badge:"Plus", plus_titre:"Ami des mots のすべてを、家族みんなで。",
  plus_avantages:["8つのテーマ、すべてのことば", "6つのゲームすべて（神経衰弱・バラバラ文字も）", "この端末で最大6人まで", "これから増えることばとゲーム"],
  plus_prix:p => `月額 ${p}`, sans_engagement:"契約期間のしばりなし、いつでも解約できます。", s_abonner:"登録する", bientot:"近日公開",
  gratuit_reste:"無料版はずっと無料：3つのテーマ、3つのゲーム、今日のチャレンジと復習。",
  deja_abonne:"すでに登録しています", code_abo:"登録コード", code_aide:"このコードを控えておいてください。別の端末で登録を復元できます。", verifier:"確認",
  abo_actif:d => `登録中${d ? `（${d}まで）` : ''}。ありがとうございます！`, abo_inconnu:"コードが見つからないか、登録が終了しています。", hors_ligne:"今は確認できません。あとでもう一度お試しください。", gerer_abo:"登録の管理・解約", decouvrir_plus:"Ami des mots Plus を見る",
  apropos_texte:"Ami des mots は、16の言語で、絵を見ながらことばを覚えて復習するゲームです。これはゲームで、何かを治療するものでも、専門家の代わりになるものでもありません。アカウントも広告もなく、進み具合はこの端末に残ります。登録については匿名のコードだけを確認し、支払いは Stripe が扱います。"
}
};
for(const l in V2) if(window.TEXTES[l]) Object.assign(window.TEXTES[l], V2[l]);
})();

// ── v3 : 50 jeux (19 sortes × niveaux) ──
(function(){
const V3 = {
fr:{
  fam_images:"Images", fam_ecoute:"Écoute", fam_traduction:"Traduction", fam_lettres:"Lettres", fam_memoire:"Mémoire et paires", fam_defis:"Défis",
  niv_f:"Facile", niv_n:"Normal", niv_e:"Expert", jeux_total:n => `${n} jeux dans ce thème`,
  j_traduction:"Traduction", j_traduction_inverse:"Que veut dire ce mot ?", j_ecoute_mot:"Écoute et lis", j_intrus:"L'intrus", j_ombre:"Ombres", j_devinette:"Image floue",
  j_premiere_lettre:"Première lettre", j_lettre_manquante:"Lettre manquante", j_memoire_trad:"Mémoire des traductions", j_relier:"Relier", j_panier:"Le bon panier", j_chrono:"Contre la montre", j_grand_quiz:"Grand quiz",
  a_traduction:l => `Comment dit-on ce mot en ${l} ?`, a_traduction_inverse:"Choisissez le mot qui a le même sens.", a_ecoute_mot:"Écoutez, puis touchez le bon mot écrit.",
  a_intrus:"Une image n'est pas du même groupe : laquelle ?", a_ombre:"Qui se cache dans l'ombre ?", a_devinette:"L'image devient nette : trouvez-la vite !",
  a_premiere_lettre:"Par quelle lettre commence ce mot ?", a_lettre_manquante:"Quelle lettre manque ?", a_memoire_trad:"Retrouvez chaque mot et sa traduction.",
  a_relier:"Touchez une image, puis son mot.", a_panier:"Dans quel panier va-t-il ?", a_chrono:"Le plus de bonnes réponses en 60 secondes.", a_grand_quiz:"15 questions de toutes sortes.",
  score:n => `${n} bonnes réponses`, temps_fini:"Temps écoulé !",
  plus_court:"les 50 jeux et tous les thèmes",
  plus_avantages:["Les 50 jeux (19 sortes, 3 niveaux)", "Les 8 thèmes, tous les mots", "Jusqu'à 6 joueurs sur l'appareil", "Les nouveaux mots et jeux à venir"],
  gratuit_reste:"La version gratuite reste gratuite : 10 jeux (dont la traduction), 3 thèmes, le défi du jour et la révision."
},
en:{
  fam_images:"Pictures", fam_ecoute:"Listening", fam_traduction:"Translation", fam_lettres:"Letters", fam_memoire:"Memory and pairs", fam_defis:"Challenges",
  niv_f:"Easy", niv_n:"Normal", niv_e:"Expert", jeux_total:n => `${n} games in this theme`,
  j_traduction:"Translation", j_traduction_inverse:"What does it mean?", j_ecoute_mot:"Listen and read", j_intrus:"Odd one out", j_ombre:"Shadows", j_devinette:"Blurry picture",
  j_premiere_lettre:"First letter", j_lettre_manquante:"Missing letter", j_memoire_trad:"Translation memory", j_relier:"Match up", j_panier:"The right basket", j_chrono:"Against the clock", j_grand_quiz:"Big quiz",
  a_traduction:l => `How do you say this word in ${l}?`, a_traduction_inverse:"Pick the word with the same meaning.", a_ecoute_mot:"Listen, then tap the right written word.",
  a_intrus:"One picture doesn't belong: which one?", a_ombre:"Who is hiding in the shadow?", a_devinette:"The picture gets sharper: find it fast!",
  a_premiere_lettre:"What letter does this word start with?", a_lettre_manquante:"Which letter is missing?", a_memoire_trad:"Match each word with its translation.",
  a_relier:"Tap a picture, then its word.", a_panier:"Which basket does it go in?", a_chrono:"As many right answers as you can in 60 seconds.", a_grand_quiz:"15 questions of every kind.",
  score:n => `${n} right answers`, temps_fini:"Time's up!",
  plus_court:"all 50 games and every theme",
  plus_avantages:["All 50 games (19 kinds, 3 levels)", "All 8 themes, every word", "Up to 6 players on this device", "New words and games as they come"],
  gratuit_reste:"The free version stays free: 10 games (including translation), 3 themes, the daily challenge and review."
},
es:{
  fam_images:"Imágenes", fam_ecoute:"Escucha", fam_traduction:"Traducción", fam_lettres:"Letras", fam_memoire:"Memoria y parejas", fam_defis:"Retos",
  niv_f:"Fácil", niv_n:"Normal", niv_e:"Experto", jeux_total:n => `${n} juegos en este tema`,
  j_traduction:"Traducción", j_traduction_inverse:"¿Qué significa?", j_ecoute_mot:"Escucha y lee", j_intrus:"El intruso", j_ombre:"Sombras", j_devinette:"Imagen borrosa",
  j_premiere_lettre:"Primera letra", j_lettre_manquante:"Letra que falta", j_memoire_trad:"Memoria de traducciones", j_relier:"Unir", j_panier:"La cesta correcta", j_chrono:"Contrarreloj", j_grand_quiz:"Gran concurso",
  a_traduction:l => `¿Cómo se dice esta palabra en ${l}?`, a_traduction_inverse:"Elige la palabra que significa lo mismo.", a_ecoute_mot:"Escucha y toca la palabra escrita correcta.",
  a_intrus:"Una imagen no es del mismo grupo: ¿cuál?", a_ombre:"¿Quién se esconde en la sombra?", a_devinette:"La imagen se aclara: ¡adivínala rápido!",
  a_premiere_lettre:"¿Con qué letra empieza esta palabra?", a_lettre_manquante:"¿Qué letra falta?", a_memoire_trad:"Encuentra cada palabra y su traducción.",
  a_relier:"Toca una imagen y luego su palabra.", a_panier:"¿En qué cesta va?", a_chrono:"Todas las respuestas correctas que puedas en 60 segundos.", a_grand_quiz:"15 preguntas de todo tipo.",
  score:n => `${n} respuestas correctas`, temps_fini:"¡Se acabó el tiempo!",
  plus_court:"los 50 juegos y todos los temas",
  plus_avantages:["Los 50 juegos (19 tipos, 3 niveles)", "Los 8 temas, todas las palabras", "Hasta 6 jugadores en el dispositivo", "Las nuevas palabras y juegos que lleguen"],
  gratuit_reste:"La versión gratuita sigue siendo gratuita: 10 juegos (con la traducción), 3 temas, el reto del día y el repaso."
},
it:{
  fam_images:"Immagini", fam_ecoute:"Ascolto", fam_traduction:"Traduzione", fam_lettres:"Lettere", fam_memoire:"Memoria e coppie", fam_defis:"Sfide",
  niv_f:"Facile", niv_n:"Normale", niv_e:"Esperto", jeux_total:n => `${n} giochi in questo tema`,
  j_traduction:"Traduzione", j_traduction_inverse:"Che cosa significa?", j_ecoute_mot:"Ascolta e leggi", j_intrus:"L'intruso", j_ombre:"Ombre", j_devinette:"Immagine sfocata",
  j_premiere_lettre:"Prima lettera", j_lettre_manquante:"Lettera mancante", j_memoire_trad:"Memoria delle traduzioni", j_relier:"Collega", j_panier:"Il cesto giusto", j_chrono:"Contro il tempo", j_grand_quiz:"Grande quiz",
  a_traduction:l => `Come si dice questa parola in ${l}?`, a_traduction_inverse:"Scegli la parola con lo stesso significato.", a_ecoute_mot:"Ascolta, poi tocca la parola scritta giusta.",
  a_intrus:"Un'immagine non è dello stesso gruppo: quale?", a_ombre:"Chi si nasconde nell'ombra?", a_devinette:"L'immagine diventa nitida: indovinala in fretta!",
  a_premiere_lettre:"Con quale lettera inizia questa parola?", a_lettre_manquante:"Quale lettera manca?", a_memoire_trad:"Trova ogni parola e la sua traduzione.",
  a_relier:"Tocca un'immagine, poi la sua parola.", a_panier:"In quale cesto va?", a_chrono:"Più risposte giuste possibili in 60 secondi.", a_grand_quiz:"15 domande di ogni tipo.",
  score:n => `${n} risposte giuste`, temps_fini:"Tempo scaduto!",
  plus_court:"i 50 giochi e tutti i temi",
  plus_avantages:["Tutti i 50 giochi (19 tipi, 3 livelli)", "Tutti gli 8 temi, tutte le parole", "Fino a 6 giocatori sul dispositivo", "Le nuove parole e i nuovi giochi in arrivo"],
  gratuit_reste:"La versione gratuita resta gratuita: 10 giochi (compresa la traduzione), 3 temi, la sfida del giorno e il ripasso."
},
pt:{
  fam_images:"Imagens", fam_ecoute:"Ouvir", fam_traduction:"Tradução", fam_lettres:"Letras", fam_memoire:"Memória e pares", fam_defis:"Desafios",
  niv_f:"Fácil", niv_n:"Normal", niv_e:"Especialista", jeux_total:n => `${n} jogos neste tema`,
  j_traduction:"Tradução", j_traduction_inverse:"O que quer dizer?", j_ecoute_mot:"Ouve e lê", j_intrus:"O intruso", j_ombre:"Sombras", j_devinette:"Imagem desfocada",
  j_premiere_lettre:"Primeira letra", j_lettre_manquante:"Letra em falta", j_memoire_trad:"Memória das traduções", j_relier:"Ligar", j_panier:"O cesto certo", j_chrono:"Contra o relógio", j_grand_quiz:"Grande quiz",
  a_traduction:l => `Como se diz esta palavra em ${l}?`, a_traduction_inverse:"Escolha a palavra com o mesmo sentido.", a_ecoute_mot:"Ouça e toque na palavra escrita certa.",
  a_intrus:"Uma imagem não é do mesmo grupo: qual?", a_ombre:"Quem se esconde na sombra?", a_devinette:"A imagem fica nítida: adivinhe depressa!",
  a_premiere_lettre:"Por que letra começa esta palavra?", a_lettre_manquante:"Que letra falta?", a_memoire_trad:"Encontre cada palavra e a sua tradução.",
  a_relier:"Toque numa imagem e depois na sua palavra.", a_panier:"Em que cesto vai?", a_chrono:"O máximo de respostas certas em 60 segundos.", a_grand_quiz:"15 perguntas de todos os tipos.",
  score:n => `${n} respostas certas`, temps_fini:"Acabou o tempo!",
  plus_court:"os 50 jogos e todos os temas",
  plus_avantages:["Os 50 jogos (19 tipos, 3 níveis)", "Os 8 temas, todas as palavras", "Até 6 jogadores no dispositivo", "As novas palavras e jogos que vierem"],
  gratuit_reste:"A versão gratuita continua gratuita: 10 jogos (incluindo a tradução), 3 temas, o desafio do dia e a revisão."
},
de:{
  fam_images:"Bilder", fam_ecoute:"Hören", fam_traduction:"Übersetzen", fam_lettres:"Buchstaben", fam_memoire:"Memory und Paare", fam_defis:"Herausforderungen",
  niv_f:"Leicht", niv_n:"Mittel", niv_e:"Profi", jeux_total:n => `${n} Spiele in diesem Thema`,
  j_traduction:"Übersetzen", j_traduction_inverse:"Was bedeutet das?", j_ecoute_mot:"Hören und lesen", j_intrus:"Was passt nicht?", j_ombre:"Schatten", j_devinette:"Unscharfes Bild",
  j_premiere_lettre:"Erster Buchstabe", j_lettre_manquante:"Fehlender Buchstabe", j_memoire_trad:"Übersetzungs-Memory", j_relier:"Verbinden", j_panier:"Der richtige Korb", j_chrono:"Gegen die Uhr", j_grand_quiz:"Großes Quiz",
  a_traduction:l => `Wie heißt dieses Wort auf ${l}?`, a_traduction_inverse:"Wähle das Wort mit derselben Bedeutung.", a_ecoute_mot:"Hör zu und tippe auf das richtige geschriebene Wort.",
  a_intrus:"Ein Bild gehört nicht dazu: welches?", a_ombre:"Wer versteckt sich im Schatten?", a_devinette:"Das Bild wird scharf: Errate es schnell!",
  a_premiere_lettre:"Mit welchem Buchstaben beginnt dieses Wort?", a_lettre_manquante:"Welcher Buchstabe fehlt?", a_memoire_trad:"Finde jedes Wort und seine Übersetzung.",
  a_relier:"Tippe auf ein Bild, dann auf sein Wort.", a_panier:"In welchen Korb gehört es?", a_chrono:"So viele richtige Antworten wie möglich in 60 Sekunden.", a_grand_quiz:"15 Fragen aller Art.",
  score:n => `${n} richtige Antworten`, temps_fini:"Die Zeit ist um!",
  plus_court:"alle 50 Spiele und alle Themen",
  plus_avantages:["Alle 50 Spiele (19 Arten, 3 Stufen)", "Alle 8 Themen, alle Wörter", "Bis zu 6 Spieler auf dem Gerät", "Neue Wörter und Spiele, sobald sie kommen"],
  gratuit_reste:"Die kostenlose Version bleibt kostenlos: 10 Spiele (mit Übersetzen), 3 Themen, die Tagesaufgabe und das Wiederholen."
},
ar:{
  fam_images:"الصور", fam_ecoute:"الاستماع", fam_traduction:"الترجمة", fam_lettres:"الحروف", fam_memoire:"الذاكرة والأزواج", fam_defis:"التحدّيات",
  niv_f:"سهل", niv_n:"عادي", niv_e:"خبير", jeux_total:n => `${n} لعبة في هذا الموضوع`,
  j_traduction:"الترجمة", j_traduction_inverse:"ماذا تعني هذه الكلمة؟", j_ecoute_mot:"استمع واقرأ", j_intrus:"الدخيل", j_ombre:"الظلال", j_devinette:"صورة ضبابية",
  j_premiere_lettre:"الحرف الأول", j_lettre_manquante:"الحرف الناقص", j_memoire_trad:"ذاكرة الترجمات", j_relier:"صِل", j_panier:"السلة الصحيحة", j_chrono:"سباق مع الوقت", j_grand_quiz:"المسابقة الكبرى",
  a_traduction:l => `كيف تُقال هذه الكلمة بـ${l}؟`, a_traduction_inverse:"اختر الكلمة التي لها المعنى نفسه.", a_ecoute_mot:"استمع ثم المس الكلمة المكتوبة الصحيحة.",
  a_intrus:"صورة ليست من المجموعة نفسها: أيّها؟", a_ombre:"من يختبئ في الظل؟", a_devinette:"الصورة تتضح: اعرفها بسرعة!",
  a_premiere_lettre:"بأي حرف تبدأ هذه الكلمة؟", a_lettre_manquante:"أي حرف ناقص؟", a_memoire_trad:"اعثر على كل كلمة وترجمتها.",
  a_relier:"المس صورة ثم كلمتها.", a_panier:"في أي سلة يوضع؟", a_chrono:"أكبر عدد من الإجابات الصحيحة في 60 ثانية.", a_grand_quiz:"15 سؤالًا من كل الأنواع.",
  score:n => `${n} إجابة صحيحة`, temps_fini:"انتهى الوقت!",
  plus_court:"الألعاب الخمسون وكل المواضيع",
  plus_avantages:["الألعاب الخمسون (19 نوعًا، 3 مستويات)", "المواضيع الثمانية، كل الكلمات", "حتى 6 لاعبين على الجهاز", "الكلمات والألعاب الجديدة القادمة"],
  gratuit_reste:"تبقى النسخة المجانية مجانية: 10 ألعاب (منها الترجمة) و3 مواضيع وتحدّي اليوم والمراجعة."
},
tr:{
  fam_images:"Resimler", fam_ecoute:"Dinleme", fam_traduction:"Çeviri", fam_lettres:"Harfler", fam_memoire:"Hafıza ve eşler", fam_defis:"Meydan okumalar",
  niv_f:"Kolay", niv_n:"Orta", niv_e:"Uzman", jeux_total:n => `Bu temada ${n} oyun`,
  j_traduction:"Çeviri", j_traduction_inverse:"Bu ne demek?", j_ecoute_mot:"Dinle ve oku", j_intrus:"Farklı olan", j_ombre:"Gölgeler", j_devinette:"Bulanık resim",
  j_premiere_lettre:"İlk harf", j_lettre_manquante:"Eksik harf", j_memoire_trad:"Çeviri hafızası", j_relier:"Eşleştir", j_panier:"Doğru sepet", j_chrono:"Zamana karşı", j_grand_quiz:"Büyük yarışma",
  a_traduction:l => `Bu kelime ${l} dilinde nasıl söylenir?`, a_traduction_inverse:"Aynı anlama gelen kelimeyi seç.", a_ecoute_mot:"Dinle, sonra doğru yazılmış kelimeye dokun.",
  a_intrus:"Bir resim aynı gruptan değil: hangisi?", a_ombre:"Gölgede kim saklanıyor?", a_devinette:"Resim netleşiyor: çabuk bul!",
  a_premiere_lettre:"Bu kelime hangi harfle başlıyor?", a_lettre_manquante:"Hangi harf eksik?", a_memoire_trad:"Her kelimeyi ve çevirisini bul.",
  a_relier:"Bir resme, sonra kelimesine dokun.", a_panier:"Hangi sepete gider?", a_chrono:"60 saniyede olabildiğince çok doğru cevap.", a_grand_quiz:"Her türden 15 soru.",
  score:n => `${n} doğru cevap`, temps_fini:"Süre doldu!",
  plus_court:"50 oyunun hepsi ve tüm temalar",
  plus_avantages:["50 oyunun hepsi (19 tür, 3 seviye)", "8 temanın hepsi, tüm kelimeler", "Cihazda en fazla 6 oyuncu", "Gelecek yeni kelimeler ve oyunlar"],
  gratuit_reste:"Ücretsiz sürüm ücretsiz kalır: 10 oyun (çeviri dahil), 3 tema, günün görevi ve tekrar."
},
pl:{
  fam_images:"Obrazki", fam_ecoute:"Słuchanie", fam_traduction:"Tłumaczenie", fam_lettres:"Litery", fam_memoire:"Memory i pary", fam_defis:"Wyzwania",
  niv_f:"Łatwy", niv_n:"Średni", niv_e:"Ekspert", jeux_total:n => `Gry w tym temacie: ${n}`,
  j_traduction:"Tłumaczenie", j_traduction_inverse:"Co to znaczy?", j_ecoute_mot:"Słuchaj i czytaj", j_intrus:"Co nie pasuje?", j_ombre:"Cienie", j_devinette:"Rozmazany obrazek",
  j_premiere_lettre:"Pierwsza litera", j_lettre_manquante:"Brakująca litera", j_memoire_trad:"Memory tłumaczeń", j_relier:"Połącz", j_panier:"Właściwy koszyk", j_chrono:"Na czas", j_grand_quiz:"Wielki quiz",
  a_traduction:l => `Jak powiedzieć to słowo w języku: ${l}?`, a_traduction_inverse:"Wybierz słowo o tym samym znaczeniu.", a_ecoute_mot:"Posłuchaj i dotknij właściwego zapisanego słowa.",
  a_intrus:"Jeden obrazek nie pasuje do grupy: który?", a_ombre:"Kto chowa się w cieniu?", a_devinette:"Obrazek się wyostrza: zgadnij szybko!",
  a_premiere_lettre:"Na jaką literę zaczyna się to słowo?", a_lettre_manquante:"Której litery brakuje?", a_memoire_trad:"Znajdź każde słowo i jego tłumaczenie.",
  a_relier:"Dotknij obrazka, potem jego słowa.", a_panier:"Do którego koszyka?", a_chrono:"Jak najwięcej dobrych odpowiedzi w 60 sekund.", a_grand_quiz:"15 pytań różnego rodzaju.",
  score:n => `Dobre odpowiedzi: ${n}`, temps_fini:"Czas minął!",
  plus_court:"wszystkie 50 gier i wszystkie tematy",
  plus_avantages:["Wszystkie 50 gier (19 rodzajów, 3 poziomy)", "Wszystkie 8 tematów, wszystkie słowa", "Do 6 graczy na urządzeniu", "Nowe słowa i gry, gdy się pojawią"],
  gratuit_reste:"Wersja darmowa pozostaje darmowa: 10 gier (z tłumaczeniem), 3 tematy, wyzwanie dnia i powtórki."
},
uk:{
  fam_images:"Малюнки", fam_ecoute:"Слухання", fam_traduction:"Переклад", fam_lettres:"Літери", fam_memoire:"Пам'ять і пари", fam_defis:"Виклики",
  niv_f:"Легко", niv_n:"Середньо", niv_e:"Експерт", jeux_total:n => `Ігор у цій темі: ${n}`,
  j_traduction:"Переклад", j_traduction_inverse:"Що це означає?", j_ecoute_mot:"Слухай і читай", j_intrus:"Зайве", j_ombre:"Тіні", j_devinette:"Розмитий малюнок",
  j_premiere_lettre:"Перша літера", j_lettre_manquante:"Пропущена літера", j_memoire_trad:"Пам'ять перекладів", j_relier:"З'єднай", j_panier:"Правильний кошик", j_chrono:"На час", j_grand_quiz:"Велика вікторина",
  a_traduction:l => `Як сказати це слово мовою: ${l}?`, a_traduction_inverse:"Вибери слово з тим самим значенням.", a_ecoute_mot:"Послухай і торкнися правильного написаного слова.",
  a_intrus:"Один малюнок не з цієї групи: який?", a_ombre:"Хто ховається в тіні?", a_devinette:"Малюнок стає чіткішим: вгадай швидко!",
  a_premiere_lettre:"З якої літери починається це слово?", a_lettre_manquante:"Якої літери бракує?", a_memoire_trad:"Знайди кожне слово і його переклад.",
  a_relier:"Торкнися малюнка, потім його слова.", a_panier:"У який кошик?", a_chrono:"Якомога більше правильних відповідей за 60 секунд.", a_grand_quiz:"15 різних запитань.",
  score:n => `Правильних відповідей: ${n}`, temps_fini:"Час вийшов!",
  plus_court:"усі 50 ігор і всі теми",
  plus_avantages:["Усі 50 ігор (19 видів, 3 рівні)", "Усі 8 тем, усі слова", "До 6 гравців на пристрої", "Нові слова й ігри, щойно з'являться"],
  gratuit_reste:"Безкоштовна версія залишається безкоштовною: 10 ігор (з перекладом), 3 теми, завдання дня й повторення."
},
ja:{
  fam_images:"絵", fam_ecoute:"聞く", fam_traduction:"翻訳", fam_lettres:"文字", fam_memoire:"神経衰弱とペア", fam_defis:"チャレンジ",
  niv_f:"かんたん", niv_n:"ふつう", niv_e:"むずかしい", jeux_total:n => `このテーマのゲーム：${n}`,
  j_traduction:"翻訳", j_traduction_inverse:"どういう意味？", j_ecoute_mot:"聞いて読む", j_intrus:"なかまはずれ", j_ombre:"シルエット", j_devinette:"ぼやけた絵",
  j_premiere_lettre:"さいしょの文字", j_lettre_manquante:"ぬけた文字", j_memoire_trad:"翻訳の神経衰弱", j_relier:"線でつなぐ", j_panier:"正しいかご", j_chrono:"タイムアタック", j_grand_quiz:"大クイズ",
  a_traduction:l => `このことばは${l}で何と言う？`, a_traduction_inverse:"同じ意味のことばを選んでください。", a_ecoute_mot:"聞いて、正しく書かれたことばにタッチ。",
  a_intrus:"1枚だけなかまがちがう絵はどれ？", a_ombre:"かげにかくれているのはだれ？", a_devinette:"絵がはっきりしてくる：早く当てよう！",
  a_premiere_lettre:"このことばはどの文字で始まる？", a_lettre_manquante:"どの文字がぬけている？", a_memoire_trad:"ことばと翻訳のペアを見つけよう。",
  a_relier:"絵にタッチしてから、そのことばにタッチ。", a_panier:"どのかごに入る？", a_chrono:"60秒でできるだけたくさん正解しよう。", a_grand_quiz:"いろいろな問題が15問。",
  score:n => `正解：${n}`, temps_fini:"時間切れ！",
  plus_court:"50のゲームとすべてのテーマ",
  plus_avantages:["50のゲームすべて（19種類・3レベル）", "8つのテーマ、すべてのことば", "この端末で最大6人まで", "これから増えることばとゲーム"],
  gratuit_reste:"無料版はずっと無料：10のゲーム（翻訳も）、3つのテーマ、今日のチャレンジと復習。"
}
};
for(const l in V3) if(window.TEXTES[l]) Object.assign(window.TEXTES[l], V3[l]);
})();

// ── v3.2 : lecture facile (pensée pour les personnes dys) ──
(function(){
const V = {
fr:{ facile:"Lecture facile", facile_aide:"Plus d'espace entre les lettres, consignes lues à voix haute, 3 choix au plus, jamais de temps limité.", lire_consigne:"Écouter la consigne" },
en:{ facile:"Easy reading", facile_aide:"More space between letters, instructions read aloud, 3 choices at most, never a time limit.", lire_consigne:"Hear the instruction" },
es:{ facile:"Lectura fácil", facile_aide:"Más espacio entre las letras, instrucciones leídas en voz alta, 3 opciones como máximo, nunca con tiempo límite.", lire_consigne:"Escuchar la instrucción" },
it:{ facile:"Lettura facile", facile_aide:"Più spazio tra le lettere, istruzioni lette ad alta voce, al massimo 3 scelte, mai un limite di tempo.", lire_consigne:"Ascolta l'istruzione" },
pt:{ facile:"Leitura fácil", facile_aide:"Mais espaço entre as letras, instruções lidas em voz alta, 3 escolhas no máximo, nunca com limite de tempo.", lire_consigne:"Ouvir a instrução" },
de:{ facile:"Leichtes Lesen", facile_aide:"Mehr Abstand zwischen den Buchstaben, Anweisungen werden vorgelesen, höchstens 3 Antworten, nie ein Zeitlimit.", lire_consigne:"Anweisung anhören" },
ar:{ facile:"قراءة سهلة", facile_aide:"مسافة أكبر بين الحروف، والتعليمات تُقرأ بصوت عالٍ، و3 اختيارات على الأكثر، ودون أي وقت محدد.", lire_consigne:"استمع إلى التعليمات" },
tr:{ facile:"Kolay okuma", facile_aide:"Harfler arasında daha fazla boşluk, sesli okunan yönergeler, en fazla 3 seçenek, hiçbir zaman süre sınırı yok.", lire_consigne:"Yönergeyi dinle" },
pl:{ facile:"Łatwe czytanie", facile_aide:"Więcej odstępu między literami, polecenia czytane na głos, najwyżej 3 odpowiedzi, nigdy limitu czasu.", lire_consigne:"Posłuchaj polecenia" },
uk:{ facile:"Легке читання", facile_aide:"Більше простору між літерами, завдання читаються вголос, щонайбільше 3 варіанти, жодних обмежень у часі.", lire_consigne:"Послухати завдання" },
ja:{ facile:"読みやすいモード", facile_aide:"文字の間を広く、説明を読み上げ、選択肢は3つまで、時間制限なし。", lire_consigne:"説明を聞く" }
};
for(const l in V) if(window.TEXTES[l]) Object.assign(window.TEXTES[l], V[l]);
})();

// ── v4.1 : nombre de mots par langue, sauvegarde des progrès ──
(function(){
const V = {
fr:{ nb_mots:n => `${n} mots`, sauvegarde:"Mes progrès", sauvegarde_aide:"Gardez un fichier de sauvegarde : il permet de retrouver tous les joueurs et leurs progrès sur ce téléphone ou un autre.", sauvegarder:"Sauvegarder", restaurer:"Restaurer", restaure_ok:"Progrès restaurés", restaure_ko:"Ce fichier n'est pas une sauvegarde d'Ami des mots." },
en:{ nb_mots:n => `${n} words`, sauvegarde:"My progress", sauvegarde_aide:"Keep a backup file: it brings back every player and their progress on this phone or another.", sauvegarder:"Back up", restaurer:"Restore", restaure_ok:"Progress restored", restaure_ko:"This file is not an Ami des mots backup." },
es:{ nb_mots:n => `${n} palabras`, sauvegarde:"Mi progreso", sauvegarde_aide:"Guarda un archivo de copia: recupera a todos los jugadores y su progreso en este teléfono o en otro.", sauvegarder:"Guardar copia", restaurer:"Restaurar", restaure_ok:"Progreso restaurado", restaure_ko:"Este archivo no es una copia de Ami des mots." },
it:{ nb_mots:n => `${n} parole`, sauvegarde:"I miei progressi", sauvegarde_aide:"Conserva un file di backup: ritrova tutti i giocatori e i loro progressi su questo telefono o su un altro.", sauvegarder:"Salva", restaurer:"Ripristina", restaure_ok:"Progressi ripristinati", restaure_ko:"Questo file non è un backup di Ami des mots." },
pt:{ nb_mots:n => `${n} palavras`, sauvegarde:"O meu progresso", sauvegarde_aide:"Guarde um ficheiro de cópia: recupera todos os jogadores e o seu progresso neste telemóvel ou noutro.", sauvegarder:"Guardar cópia", restaurer:"Restaurar", restaure_ok:"Progresso restaurado", restaure_ko:"Este ficheiro não é uma cópia do Ami des mots." },
de:{ nb_mots:n => `${n} Wörter`, sauvegarde:"Mein Fortschritt", sauvegarde_aide:"Bewahre eine Sicherungsdatei auf: Damit holst du alle Spieler und ihren Fortschritt auf dieses oder ein anderes Handy zurück.", sauvegarder:"Sichern", restaurer:"Wiederherstellen", restaure_ok:"Fortschritt wiederhergestellt", restaure_ko:"Diese Datei ist keine Sicherung von Ami des mots." },
ar:{ nb_mots:n => `${n} كلمة`, sauvegarde:"تقدّمي", sauvegarde_aide:"احتفظ بملف نسخة احتياطية: يعيد كل اللاعبين وتقدّمهم على هذا الهاتف أو على هاتف آخر.", sauvegarder:"حفظ نسخة", restaurer:"استعادة", restaure_ok:"تمت استعادة التقدّم", restaure_ko:"هذا الملف ليس نسخة احتياطية من Ami des mots." },
tr:{ nb_mots:n => `${n} kelime`, sauvegarde:"İlerlemem", sauvegarde_aide:"Bir yedek dosyası sakla: tüm oyuncuları ve ilerlemelerini bu telefonda ya da başka birinde geri getirir.", sauvegarder:"Yedekle", restaurer:"Geri yükle", restaure_ok:"İlerleme geri yüklendi", restaure_ko:"Bu dosya bir Ami des mots yedeği değil." },
pl:{ nb_mots:n => `Słowa: ${n}`, sauvegarde:"Moje postępy", sauvegarde_aide:"Zachowaj plik kopii: przywraca wszystkich graczy i ich postępy na tym lub innym telefonie.", sauvegarder:"Zapisz kopię", restaurer:"Przywróć", restaure_ok:"Postępy przywrócone", restaure_ko:"Ten plik nie jest kopią Ami des mots." },
uk:{ nb_mots:n => `Слів: ${n}`, sauvegarde:"Мій поступ", sauvegarde_aide:"Збережи файл резервної копії: він повертає всіх гравців і їхній поступ на цьому чи іншому телефоні.", sauvegarder:"Зберегти копію", restaurer:"Відновити", restaure_ok:"Поступ відновлено", restaure_ko:"Цей файл не є копією Ami des mots." },
ja:{ nb_mots:n => `${n}語`, sauvegarde:"わたしの記録", sauvegarde_aide:"バックアップファイルを保存しておくと、この端末でも別の端末でも、全プレイヤーの記録を復元できます。", sauvegarder:"バックアップ", restaurer:"復元", restaure_ok:"記録を復元しました", restaure_ko:"このファイルは Ami des mots のバックアップではありません。" }
};
for(const l in V) if(window.TEXTES[l]) Object.assign(window.TEXTES[l], V[l]);
})();

// ── v4.2 : transparence sur les voix ──
(function(){
const V = {
fr:{ apropos_voix:"Les voix enregistrées sont lues depuis reparole.fr, hébergé par GitHub Pages. Une demande audio transmet techniquement à l’hébergeur l’adresse IP, la langue et le mot demandé. Pour le kabyle, le mot apparaît directement dans l’URL ; pour les autres langues, l’URL contient un identifiant haché, qui n’est pas un chiffrement et peut être rapproché du vocabulaire connu. Aucun nom ni aucune progression n’est envoyé." },
en:{ apropos_voix:"Recorded voices are played from reparole.fr, hosted on GitHub Pages. An audio request technically reveals to the host the device IP address, the language and the requested word. For Kabyle, the word appears directly in the URL; for other languages, the URL contains a hash identifier, which is not encryption and may be matched against known vocabulary. No name or progress is sent." },
es:{ apropos_voix:"Las voces grabadas se reproducen desde reparole.fr, alojado en GitHub Pages. Una solicitud de audio comunica técnicamente al alojamiento la dirección IP del dispositivo, el idioma y la palabra solicitada. En kabyle, la palabra aparece directamente en la URL; en los demás idiomas, la URL contiene un identificador hash, que no es un cifrado y puede relacionarse con el vocabulario conocido. No se envían nombres ni progresos." },
it:{ apropos_voix:"Le voci registrate vengono riprodotte da reparole.fr, ospitato su GitHub Pages. Una richiesta audio comunica tecnicamente all’hosting l’indirizzo IP del dispositivo, la lingua e la parola richiesta. In kabyle la parola compare direttamente nell’URL; nelle altre lingue l’URL contiene un identificatore hash, che non è una cifratura e può essere confrontato con il vocabolario noto. Non vengono inviati nomi né progressi." },
pt:{ apropos_voix:"As vozes gravadas são reproduzidas a partir de reparole.fr, alojado no GitHub Pages. Um pedido de áudio revela tecnicamente ao alojamento o endereço IP do dispositivo, o idioma e a palavra solicitada. Em cabila, a palavra aparece diretamente no URL; nos outros idiomas, o URL contém um identificador hash, que não é encriptação e pode ser comparado com o vocabulário conhecido. Não são enviados nomes nem progressos." },
de:{ apropos_voix:"Aufgenommene Stimmen werden von reparole.fr abgespielt, gehostet auf GitHub Pages. Eine Audioanfrage übermittelt dem Hosting-Anbieter technisch die IP-Adresse des Geräts, die Sprache und das angeforderte Wort. Bei Kabylisch erscheint das Wort direkt in der URL; bei anderen Sprachen enthält die URL eine Hash-Kennung, die keine Verschlüsselung ist und mit bekanntem Wortschatz abgeglichen werden kann. Namen oder Lernfortschritte werden nicht übertragen." },
ar:{ apropos_voix:"تُشغَّل الأصوات المسجّلة من reparole.fr المستضاف على GitHub Pages. يكشف طلب الصوت تقنيًا للمضيف عنوان IP للجهاز واللغة والكلمة المطلوبة. في القبائلية تظهر الكلمة مباشرةً في عنوان URL؛ أما اللغات الأخرى فيحتوي عنوان URL على معرّف تجزئة، وهو ليس تشفيرًا ويمكن مطابقته مع المفردات المعروفة. لا تُرسل الأسماء أو التقدّم." },
tr:{ apropos_voix:"Kaydedilmiş sesler GitHub Pages üzerinde barındırılan reparole.fr adresinden oynatılır. Bir ses isteği, cihazın IP adresini, dili ve istenen kelimeyi teknik olarak barındırma hizmetine bildirir. Kabyle için kelime doğrudan URL'de görünür; diğer dillerde URL, şifreleme olmayan ve bilinen kelime dağarcığıyla eşleştirilebilen bir karma kimliği içerir. Ad veya ilerleme bilgisi gönderilmez." },
pl:{ apropos_voix:"Nagrane głosy są odtwarzane z reparole.fr hostowanego w GitHub Pages. Żądanie dźwięku technicznie ujawnia hostingowi adres IP urządzenia, język i żądane słowo. W języku kabylskim słowo występuje bezpośrednio w adresie URL; w pozostałych językach adres URL zawiera identyfikator skrótu, który nie jest szyfrowaniem i można go porównać ze znanym słownictwem. Imiona ani postępy nie są wysyłane." },
uk:{ apropos_voix:"Записані голоси відтворюються з reparole.fr на GitHub Pages. Запит аудіо технічно передає хостингу IP-адресу пристрою, мову та запитане слово. Для кабільської мови слово безпосередньо міститься в URL; для інших мов URL містить хеш-ідентифікатор, який не є шифруванням і може бути зіставлений із відомим словником. Імена та поступ не надсилаються." },
ja:{ apropos_voix:"録音音声は GitHub Pages 上の reparole.fr から再生されます。音声リクエストにより、ホスティング側には端末の IP アドレス、言語、要求された単語が技術的に伝わります。カビル語では単語が URL に直接表示され、その他の言語では暗号化ではないハッシュ識別子が URL に含まれ、既知の語彙と照合できる場合があります。名前や学習記録は送信されません。" }
};
for(const l in V) if(window.TEXTES[l]) Object.assign(window.TEXTES[l], V[l]);
})();

// ── v4.4 : apprendre avant de jouer (leçons, mots présentés) ──
(function(){
const V = {
fr:{ apprendre:"Apprendre 5 mots", nouveau_mot:"Nouveau mot !", a_nouveau_mot:"Regardez, écoutez, puis on joue avec ce mot.", compris:"J'ai compris", deja_connu:"Je le connais déjà", lecon_fin:n => `${n} nouveaux mots !`, lecon_rien:"Vous avez découvert tous les mots. Révisez-les dans « À revoir »." },
en:{ apprendre:"Learn 5 words", nouveau_mot:"New word!", a_nouveau_mot:"Look, listen, then we'll play with this word.", compris:"Got it", deja_connu:"I already know it", lecon_fin:n => `${n} new words!`, lecon_rien:"You've discovered every word. Practise them in Review." },
es:{ apprendre:"Aprender 5 palabras", nouveau_mot:"¡Palabra nueva!", a_nouveau_mot:"Mira, escucha y luego jugamos con esta palabra.", compris:"Entendido", deja_connu:"Ya la conozco", lecon_fin:n => `¡${n} palabras nuevas!`, lecon_rien:"Has descubierto todas las palabras. Repásalas en «Repasar»." },
it:{ apprendre:"Impara 5 parole", nouveau_mot:"Parola nuova!", a_nouveau_mot:"Guarda, ascolta, poi giochiamo con questa parola.", compris:"Ho capito", deja_connu:"La conosco già", lecon_fin:n => `${n} parole nuove!`, lecon_rien:"Hai scoperto tutte le parole. Ripassale in «Da ripassare»." },
pt:{ apprendre:"Aprender 5 palavras", nouveau_mot:"Palavra nova!", a_nouveau_mot:"Olhe, ouça e depois jogamos com esta palavra.", compris:"Percebi", deja_connu:"Já a conheço", lecon_fin:n => `${n} palavras novas!`, lecon_rien:"Já descobriu todas as palavras. Reveja-as em «Rever»." },
de:{ apprendre:"5 Wörter lernen", nouveau_mot:"Neues Wort!", a_nouveau_mot:"Schau, hör zu, dann spielen wir mit diesem Wort.", compris:"Verstanden", deja_connu:"Kenne ich schon", lecon_fin:n => `${n} neue Wörter!`, lecon_rien:"Du hast alle Wörter entdeckt. Wiederhole sie unter „Wiederholen“." },
ar:{ apprendre:"تعلّم 5 كلمات", nouveau_mot:"كلمة جديدة!", a_nouveau_mot:"انظر واستمع، ثم نلعب بهذه الكلمة.", compris:"فهمت", deja_connu:"أعرفها من قبل", lecon_fin:n => `${n} كلمات جديدة!`, lecon_rien:"اكتشفت كل الكلمات. راجعها في «للمراجعة»." },
tr:{ apprendre:"5 kelime öğren", nouveau_mot:"Yeni kelime!", a_nouveau_mot:"Bak, dinle, sonra bu kelimeyle oynayalım.", compris:"Anladım", deja_connu:"Zaten biliyorum", lecon_fin:n => `${n} yeni kelime!`, lecon_rien:"Tüm kelimeleri keşfettin. Onları «Tekrar» bölümünde tekrar et." },
pl:{ apprendre:"Naucz się 5 słów", nouveau_mot:"Nowe słowo!", a_nouveau_mot:"Popatrz, posłuchaj, potem zagramy tym słowem.", compris:"Rozumiem", deja_connu:"Już je znam", lecon_fin:n => `Nowe słowa: ${n}!`, lecon_rien:"Poznałeś wszystkie słowa. Powtórz je w „Do powtórki”." },
uk:{ apprendre:"Вивчити 5 слів", nouveau_mot:"Нове слово!", a_nouveau_mot:"Подивись, послухай, а потім пограємо з цим словом.", compris:"Зрозуміло", deja_connu:"Я вже знаю", lecon_fin:n => `Нових слів: ${n}!`, lecon_rien:"Ти відкрив усі слова. Повторюй їх у розділі «Повторити»." },
ja:{ apprendre:"5つのことばを学ぶ", nouveau_mot:"新しいことば！", a_nouveau_mot:"見て、聞いて、それからこのことばで遊ぼう。", compris:"わかった", deja_connu:"もう知っている", lecon_fin:n => `新しいことば ${n}個！`, lecon_rien:"すべてのことばを見つけました。「復習」でおさらいしましょう。" }
};
for(const l in V) if(window.TEXTES[l]) Object.assign(window.TEXTES[l], V[l]);
})();

// ── v5 : blagues d'Ami, prononciation, conseils, mot du jour ──
// Les blagues portent sur Ami ou sur le mot, JAMAIS sur la personne.
(function(){
const V = {
fr:{
  blagues:["Oups ! Hier, j'ai dit bonjour à un lampadaire. Tout le monde se trompe !", "Pas grave ! Même les hiboux se trompent… surtout avant leur goûter de minuit.", "Ce mot joue à cache-cache avec nous. On le retrouve ?", "Tu as essayé, et c'est comme ça que le cerveau se muscle !", "Hou hou ! Mes plumes se sont emmêlées aussi. Encore une fois ?", "Ce mot est farceur : il s'est déguisé ! Regardons mieux.", "Une erreur, c'est un mot qui dit : « Reviens me voir ! »", "Mon arrière-grand-hibou confondait un chat et un chapeau. Véridique !", "Oh ! Une erreur sauvage apparaît… On l'attrape ensemble ?", "Chaque erreur me fait pousser une plume de sagesse. Merci !", "Tu viens d'inventer un nouveau mot ! On cherche l'autre ?", "J'ai une collection d'erreurs. Elles sont toutes très jolies."],
  lentement:"Écouter lentement", bouche:"Voir la bouche", a_toi:"À toi !", a_toi_aide:"Écoute Ami, puis appuie sur le micro et dis le mot.", parler:"Parler", j_ecoute:"Je t'écoute…", dis_le_mot:"Dis le mot maintenant !",
  me_reecouter:"Me réécouter", ecouter_ami:"Écouter Ami", a_toi_prive:"Ta voix reste sur cet appareil : rien n'est envoyé ni gardé.", a_toi_bravo:"Bravo, tu as osé parler ! Compare ta voix à celle d'Ami.",
  sans_micro:"Pas de micro ? Dis le mot à voix haute : c'est déjà très bien !", je_l_ai_dit:"Je l'ai dit !", reessayer:"Réessayer",
  mot_du_jour:"Le mot du jour", astuce_ami:"L'astuce d'Ami", toutes_astuces:"Toutes les astuces", astuces:"Astuces", astuces_titre:"Comment parler une autre langue", astuces_intro:"Personne ne naît en parlant une langue : tout le monde l'apprend, petit à petit. Voici mes secrets.",
  conseils:[["Un peu chaque jour.", "Cinq minutes par jour valent mieux qu'une heure le dimanche : le cerveau aime les rendez-vous réguliers."], ["Parle à voix haute.", "Dis chaque mot, même tout seul. Ta bouche apprend aussi, pas seulement tes yeux."], ["Répète comme un écho.", "Écoute, puis répète tout de suite avec la même musique. Le bouton 🐢 aide pour les mots difficiles."], ["Ose te tromper.", "Personne ne parle parfaitement au début. Chaque erreur te rapproche du bon mot."], ["Colle des mots partout.", "Mets de petites étiquettes sur les objets de la maison : porte, table, fenêtre…"], ["Apprends en famille.", "Demande à un parent ou à un grand-parent de te dire les mots de sa langue, et apprends-lui les tiens."], ["Chante et écoute.", "Chansons, dessins animés, histoires : ton oreille s'habitue aux sons sans effort."], ["Revois au bon moment.", "« À revoir » te redonne les mots juste avant que tu les oublies. C'est le secret des mots qui restent."]],
  ou_bouche_titre:"Comment la bouche fait ce mot", ou_nez:"l'air passe par le nez", ou_voix:"la gorge vibre", ou_normal:"Normal", ou_lent:"Lentement", ou_fermer:"Fermer", ou_schema_note:"Un dessin simple pour s'aider ; la voix reste le meilleur modèle.", ou_bouche_btn:"Voir la bouche"
},
en:{
  blagues:["Oops! Yesterday I said hello to a lamppost. Everyone gets things wrong!", "No problem! Even owls make mistakes… especially before their midnight snack.", "This word is playing hide-and-seek with us. Shall we find it?", "You tried, and that's how a brain gets stronger!", "Hoo hoo! My feathers got tangled too. One more time?", "This word is a joker: it's wearing a disguise! Let's look again.", "A mistake is just a word saying: “Come back and see me!”", "My great-grandfather owl mixed up a cat and a hat. True story!", "Oh! A wild mistake appears… Shall we catch it together?", "Every mistake grows me a feather of wisdom. Thanks!", "You just invented a new word! Shall we find the other one?", "I collect mistakes. They're all very pretty."],
  lentement:"Listen slowly", bouche:"See the mouth", a_toi:"Your turn!", a_toi_aide:"Listen to Ami, then press the mic and say the word.", parler:"Speak", j_ecoute:"I'm listening…", dis_le_mot:"Say the word now!",
  me_reecouter:"Hear myself", ecouter_ami:"Hear Ami", a_toi_prive:"Your voice stays on this device: nothing is sent or kept.", a_toi_bravo:"Well done, you dared to speak! Compare your voice with Ami's.",
  sans_micro:"No microphone? Say the word out loud: that's already great!", je_l_ai_dit:"I said it!", reessayer:"Try again",
  mot_du_jour:"Word of the day", astuce_ami:"Ami's tip", toutes_astuces:"All the tips", astuces:"Tips", astuces_titre:"How to speak another language", astuces_intro:"Nobody is born speaking a language: everyone learns it, little by little. Here are my secrets.",
  conseils:[["A little every day.", "Five minutes a day beat one hour on Sunday: the brain loves regular appointments."], ["Speak out loud.", "Say every word, even on your own. Your mouth learns too, not just your eyes."], ["Repeat like an echo.", "Listen, then repeat straight away with the same melody. The 🐢 button helps with hard words."], ["Dare to make mistakes.", "Nobody speaks perfectly at first. Every mistake brings you closer to the right word."], ["Stick words everywhere.", "Put little labels on things at home: door, table, window…"], ["Learn as a family.", "Ask a parent or grandparent to tell you words in their language, and teach them yours."], ["Sing and listen.", "Songs, cartoons, stories: your ear gets used to the sounds without effort."], ["Review at the right time.", "Review gives you words back just before you forget them. That's the secret of words that stick."]],
  ou_bouche_titre:"How the mouth makes this word", ou_nez:"air goes through the nose", ou_voix:"the throat vibrates", ou_normal:"Normal", ou_lent:"Slowly", ou_fermer:"Close", ou_schema_note:"A simple drawing to help; the voice is still the best model.", ou_bouche_btn:"See the mouth"
},
es:{
  blagues:["¡Uy! Ayer saludé a una farola. ¡Todo el mundo se equivoca!", "¡No pasa nada! Hasta los búhos se equivocan… sobre todo antes de su merienda de medianoche.", "Esta palabra juega al escondite con nosotros. ¿La buscamos?", "Lo has intentado, ¡y así es como el cerebro se pone fuerte!", "¡Uh, uh! A mí también se me enredaron las plumas. ¿Otra vez?", "Esta palabra es bromista: ¡se ha disfrazado! Miremos mejor.", "Un error es una palabra que dice: «¡Vuelve a verme!»", "Mi bisabuelo búho confundía un gato con un sombrero. ¡De verdad!", "¡Oh! Aparece un error salvaje… ¿Lo atrapamos juntos?", "Cada error me hace crecer una pluma de sabiduría. ¡Gracias!", "¡Acabas de inventar una palabra nueva! ¿Buscamos la otra?", "Colecciono errores. Todos son muy bonitos."],
  lentement:"Escuchar despacio", bouche:"Ver la boca", a_toi:"¡Te toca!", a_toi_aide:"Escucha a Ami, luego pulsa el micro y di la palabra.", parler:"Hablar", j_ecoute:"Te escucho…", dis_le_mot:"¡Di la palabra ahora!",
  me_reecouter:"Volver a oírme", ecouter_ami:"Escuchar a Ami", a_toi_prive:"Tu voz se queda en este dispositivo: no se envía ni se guarda nada.", a_toi_bravo:"¡Bravo, te has atrevido a hablar! Compara tu voz con la de Ami.",
  sans_micro:"¿No hay micro? Di la palabra en voz alta: ¡eso ya está muy bien!", je_l_ai_dit:"¡Lo he dicho!", reessayer:"Reintentar",
  mot_du_jour:"La palabra del día", astuce_ami:"El truco de Ami", toutes_astuces:"Todos los trucos", astuces:"Trucos", astuces_titre:"Cómo hablar otro idioma", astuces_intro:"Nadie nace hablando un idioma: todos lo aprendemos poco a poco. Estos son mis secretos.",
  conseils:[["Un poco cada día.", "Cinco minutos al día valen más que una hora el domingo: al cerebro le encantan las citas regulares."], ["Habla en voz alta.", "Di cada palabra, aunque estés solo. Tu boca también aprende, no solo tus ojos."], ["Repite como un eco.", "Escucha y repite enseguida con la misma música. El botón 🐢 ayuda con las palabras difíciles."], ["Atrévete a equivocarte.", "Nadie habla perfectamente al principio. Cada error te acerca a la palabra correcta."], ["Pega palabras por todas partes.", "Pon pequeñas etiquetas en las cosas de casa: puerta, mesa, ventana…"], ["Aprende en familia.", "Pide a un padre o a un abuelo que te diga palabras de su idioma, y enséñale las tuyas."], ["Canta y escucha.", "Canciones, dibujos animados, cuentos: tu oído se acostumbra a los sonidos sin esfuerzo."], ["Repasa en el momento justo.", "«Repasar» te devuelve las palabras justo antes de que las olvides. Es el secreto de las palabras que se quedan."]],
  ou_bouche_titre:"Cómo hace la boca esta palabra", ou_nez:"el aire pasa por la nariz", ou_voix:"la garganta vibra", ou_normal:"Normal", ou_lent:"Despacio", ou_fermer:"Cerrar", ou_schema_note:"Un dibujo sencillo para ayudar; la voz sigue siendo el mejor modelo.", ou_bouche_btn:"Ver la boca"
},
it:{
  blagues:["Ops! Ieri ho salutato un lampione. Tutti sbagliano!", "Niente di grave! Anche i gufi sbagliano… soprattutto prima della merenda di mezzanotte.", "Questa parola gioca a nascondino con noi. La ritroviamo?", "Hai provato, ed è così che il cervello diventa forte!", "Uh uh! Anche le mie piume si sono aggrovigliate. Un'altra volta?", "Questa parola è burlona: si è travestita! Guardiamo meglio.", "Un errore è una parola che dice: «Torna a trovarmi!»", "Il mio bisnonno gufo confondeva un gatto con un cappello. Giuro!", "Oh! Appare un errore selvatico… Lo catturiamo insieme?", "Ogni errore mi fa crescere una piuma di saggezza. Grazie!", "Hai appena inventato una parola nuova! Cerchiamo l'altra?", "Colleziono errori. Sono tutti bellissimi."],
  lentement:"Ascolta piano", bouche:"Guarda la bocca", a_toi:"Tocca a te!", a_toi_aide:"Ascolta Ami, poi premi il microfono e di' la parola.", parler:"Parla", j_ecoute:"Ti ascolto…", dis_le_mot:"Di' la parola adesso!",
  me_reecouter:"Riascoltarmi", ecouter_ami:"Ascolta Ami", a_toi_prive:"La tua voce resta su questo dispositivo: niente viene inviato o conservato.", a_toi_bravo:"Bravo, hai osato parlare! Confronta la tua voce con quella di Ami.",
  sans_micro:"Niente microfono? Di' la parola ad alta voce: va già benissimo!", je_l_ai_dit:"L'ho detta!", reessayer:"Riprova",
  mot_du_jour:"La parola del giorno", astuce_ami:"Il trucco di Ami", toutes_astuces:"Tutti i trucchi", astuces:"Trucchi", astuces_titre:"Come parlare un'altra lingua", astuces_intro:"Nessuno nasce parlando una lingua: tutti la imparano, poco a poco. Ecco i miei segreti.",
  conseils:[["Un po' ogni giorno.", "Cinque minuti al giorno valgono più di un'ora la domenica: il cervello ama gli appuntamenti regolari."], ["Parla ad alta voce.", "Di' ogni parola, anche da solo. Anche la tua bocca impara, non solo gli occhi."], ["Ripeti come un'eco.", "Ascolta, poi ripeti subito con la stessa musica. Il pulsante 🐢 aiuta con le parole difficili."], ["Osa sbagliare.", "Nessuno parla perfettamente all'inizio. Ogni errore ti avvicina alla parola giusta."], ["Attacca parole ovunque.", "Metti piccole etichette sugli oggetti di casa: porta, tavolo, finestra…"], ["Impara in famiglia.", "Chiedi a un genitore o a un nonno di dirti le parole della sua lingua, e insegnagli le tue."], ["Canta e ascolta.", "Canzoni, cartoni animati, storie: il tuo orecchio si abitua ai suoni senza fatica."], ["Ripassa al momento giusto.", "«Da ripassare» ti ridà le parole proprio prima che tu le dimentichi. È il segreto delle parole che restano."]],
  ou_bouche_titre:"Come la bocca fa questa parola", ou_nez:"l'aria passa dal naso", ou_voix:"la gola vibra", ou_normal:"Normale", ou_lent:"Piano", ou_fermer:"Chiudi", ou_schema_note:"Un disegno semplice per aiutarsi; la voce resta il modello migliore.", ou_bouche_btn:"Guarda la bocca"
},
pt:{
  blagues:["Ups! Ontem disse olá a um candeeiro de rua. Toda a gente se engana!", "Não faz mal! Até os mochos se enganam… sobretudo antes do lanche da meia-noite.", "Esta palavra está a brincar às escondidas connosco. Vamos encontrá-la?", "Tentaste, e é assim que o cérebro fica forte!", "Uh uh! As minhas penas também se enredaram. Mais uma vez?", "Esta palavra é brincalhona: mascarou-se! Vamos olhar melhor.", "Um erro é uma palavra a dizer: «Volta a visitar-me!»", "O meu bisavô mocho confundia um gato com um chapéu. Verdade!", "Oh! Aparece um erro selvagem… Apanhamo-lo juntos?", "Cada erro faz-me crescer uma pena de sabedoria. Obrigado!", "Acabaste de inventar uma palavra nova! Procuramos a outra?", "Faço coleção de erros. São todos muito bonitos."],
  lentement:"Ouvir devagar", bouche:"Ver a boca", a_toi:"A tua vez!", a_toi_aide:"Ouve o Ami, depois carrega no microfone e diz a palavra.", parler:"Falar", j_ecoute:"Estou a ouvir…", dis_le_mot:"Diz a palavra agora!",
  me_reecouter:"Ouvir-me outra vez", ecouter_ami:"Ouvir o Ami", a_toi_prive:"A tua voz fica neste dispositivo: nada é enviado nem guardado.", a_toi_bravo:"Boa, tiveste coragem de falar! Compara a tua voz com a do Ami.",
  sans_micro:"Sem microfone? Diz a palavra em voz alta: isso já é ótimo!", je_l_ai_dit:"Já disse!", reessayer:"Tentar outra vez",
  mot_du_jour:"A palavra do dia", astuce_ami:"A dica do Ami", toutes_astuces:"Todas as dicas", astuces:"Dicas", astuces_titre:"Como falar outra língua", astuces_intro:"Ninguém nasce a falar uma língua: todos a aprendem, aos poucos. Aqui estão os meus segredos.",
  conseils:[["Um pouco todos os dias.", "Cinco minutos por dia valem mais do que uma hora ao domingo: o cérebro adora encontros regulares."], ["Fala em voz alta.", "Diz cada palavra, mesmo sozinho. A tua boca também aprende, não só os teus olhos."], ["Repete como um eco.", "Ouve e repete logo a seguir com a mesma música. O botão 🐢 ajuda nas palavras difíceis."], ["Não tenhas medo de errar.", "Ninguém fala perfeitamente no início. Cada erro aproxima-te da palavra certa."], ["Cola palavras por todo o lado.", "Põe pequenas etiquetas nas coisas de casa: porta, mesa, janela…"], ["Aprende em família.", "Pede a um pai ou a um avô que te diga as palavras da língua dele, e ensina-lhe as tuas."], ["Canta e ouve.", "Canções, desenhos animados, histórias: o teu ouvido habitua-se aos sons sem esforço."], ["Revê no momento certo.", "«Rever» devolve-te as palavras mesmo antes de as esqueceres. É o segredo das palavras que ficam."]],
  ou_bouche_titre:"Como a boca faz esta palavra", ou_nez:"o ar passa pelo nariz", ou_voix:"a garganta vibra", ou_normal:"Normal", ou_lent:"Devagar", ou_fermer:"Fechar", ou_schema_note:"Um desenho simples para ajudar; a voz continua a ser o melhor modelo.", ou_bouche_btn:"Ver a boca"
},
de:{
  blagues:["Hoppla! Gestern habe ich eine Laterne begrüßt. Jeder irrt sich mal!", "Macht nichts! Sogar Eulen irren sich … vor allem vor ihrem Mitternachtssnack.", "Dieses Wort spielt Verstecken mit uns. Finden wir es?", "Du hast es versucht – genau so wird das Gehirn stark!", "Hu hu! Meine Federn haben sich auch verheddert. Noch einmal?", "Dieses Wort ist ein Spaßvogel: Es hat sich verkleidet! Schauen wir genauer hin.", "Ein Fehler ist ein Wort, das sagt: „Besuch mich wieder!“", "Mein Urgroßvater-Uhu hat eine Katze mit einem Hut verwechselt. Ehrlich!", "Oh! Ein wilder Fehler erscheint … Fangen wir ihn zusammen?", "Bei jedem Fehler wächst mir eine Feder der Weisheit. Danke!", "Du hast gerade ein neues Wort erfunden! Suchen wir das andere?", "Ich sammle Fehler. Sie sind alle sehr hübsch."],
  lentement:"Langsam anhören", bouche:"Den Mund sehen", a_toi:"Du bist dran!", a_toi_aide:"Hör Ami zu, drück dann aufs Mikrofon und sag das Wort.", parler:"Sprechen", j_ecoute:"Ich höre zu …", dis_le_mot:"Sag jetzt das Wort!",
  me_reecouter:"Mich anhören", ecouter_ami:"Ami anhören", a_toi_prive:"Deine Stimme bleibt auf diesem Gerät: Nichts wird gesendet oder gespeichert.", a_toi_bravo:"Super, du hast dich getraut zu sprechen! Vergleiche deine Stimme mit Amis.",
  sans_micro:"Kein Mikrofon? Sag das Wort laut: Das ist schon toll!", je_l_ai_dit:"Ich hab's gesagt!", reessayer:"Nochmal",
  mot_du_jour:"Das Wort des Tages", astuce_ami:"Amis Tipp", toutes_astuces:"Alle Tipps", astuces:"Tipps", astuces_titre:"Wie man eine andere Sprache spricht", astuces_intro:"Niemand kommt sprechend auf die Welt: Jeder lernt eine Sprache, nach und nach. Hier sind meine Geheimnisse.",
  conseils:[["Jeden Tag ein bisschen.", "Fünf Minuten am Tag sind besser als eine Stunde am Sonntag: Das Gehirn liebt regelmäßige Termine."], ["Sprich laut.", "Sag jedes Wort, auch wenn du allein bist. Auch dein Mund lernt, nicht nur deine Augen."], ["Wiederhole wie ein Echo.", "Hör zu und sprich sofort mit derselben Melodie nach. Der 🐢-Knopf hilft bei schweren Wörtern."], ["Trau dich, Fehler zu machen.", "Niemand spricht am Anfang perfekt. Jeder Fehler bringt dich dem richtigen Wort näher."], ["Klebe überall Wörter hin.", "Bring kleine Zettel an Dingen im Haus an: Tür, Tisch, Fenster …"], ["Lerne mit der Familie.", "Bitte Eltern oder Großeltern, dir Wörter ihrer Sprache zu sagen, und bring ihnen deine bei."], ["Sing und hör zu.", "Lieder, Zeichentrickfilme, Geschichten: Dein Ohr gewöhnt sich mühelos an die Laute."], ["Wiederhole zur richtigen Zeit.", "„Wiederholen“ gibt dir die Wörter zurück, kurz bevor du sie vergisst. Das ist das Geheimnis der Wörter, die bleiben."]],
  ou_bouche_titre:"Wie der Mund dieses Wort macht", ou_nez:"Luft geht durch die Nase", ou_voix:"der Hals vibriert", ou_normal:"Normal", ou_lent:"Langsam", ou_fermer:"Schließen", ou_schema_note:"Eine einfache Zeichnung als Hilfe; die Stimme bleibt das beste Vorbild.", ou_bouche_btn:"Den Mund sehen"
},
ar:{
  blagues:["أوه! بالأمس قلت مرحبًا لعمود إنارة. كلنا نخطئ!", "لا بأس! حتى البوم تخطئ… خصوصًا قبل وجبة منتصف الليل.", "هذه الكلمة تلعب معنا الغمّيضة. هل نجدها؟", "لقد حاولت، وهكذا يصبح الدماغ أقوى!", "هوو هوو! ريشي تشابك أيضًا. مرة أخرى؟", "هذه الكلمة مازحة: لقد تنكّرت! لننظر جيدًا.", "الخطأ كلمة تقول: «عُد لزيارتي!»", "جدّ جدّي البوم كان يخلط بين القطة والقبعة. حقًا!", "أوه! ظهر خطأ برّي… هل نمسكه معًا؟", "كل خطأ تنبت لي منه ريشة حكمة. شكرًا!", "لقد اخترعت كلمة جديدة! هل نبحث عن الأخرى؟", "أنا أجمع الأخطاء. كلها جميلة جدًا."],
  lentement:"استمع ببطء", bouche:"شاهد الفم", a_toi:"دورك!", a_toi_aide:"استمع إلى آمي، ثم اضغط على الميكروفون وقل الكلمة.", parler:"تكلّم", j_ecoute:"أنا أستمع…", dis_le_mot:"قل الكلمة الآن!",
  me_reecouter:"أستمع إلى نفسي", ecouter_ami:"استمع إلى آمي", a_toi_prive:"صوتك يبقى على هذا الجهاز: لا شيء يُرسَل أو يُحفَظ.", a_toi_bravo:"أحسنت، تجرّأت على الكلام! قارن صوتك بصوت آمي.",
  sans_micro:"لا يوجد ميكروفون؟ قل الكلمة بصوت عالٍ: هذا رائع بالفعل!", je_l_ai_dit:"قلتها!", reessayer:"حاول مجددًا",
  mot_du_jour:"كلمة اليوم", astuce_ami:"نصيحة آمي", toutes_astuces:"كل النصائح", astuces:"نصائح", astuces_titre:"كيف تتكلّم لغة أخرى", astuces_intro:"لا أحد يولد وهو يتكلّم لغة: الجميع يتعلّمها شيئًا فشيئًا. هذه أسراري.",
  conseils:[["قليلًا كل يوم.", "خمس دقائق يوميًا أفضل من ساعة يوم الأحد: الدماغ يحب المواعيد المنتظمة."], ["تكلّم بصوت عالٍ.", "قل كل كلمة، حتى وأنت وحدك. فمك يتعلّم أيضًا، لا عيناك فقط."], ["كرّر مثل الصدى.", "استمع ثم كرّر فورًا بالنغمة نفسها. زر 🐢 يساعد مع الكلمات الصعبة."], ["لا تخف من الخطأ.", "لا أحد يتكلّم بإتقان في البداية. كل خطأ يقرّبك من الكلمة الصحيحة."], ["ألصق الكلمات في كل مكان.", "ضع ملصقات صغيرة على أشياء البيت: باب، طاولة، نافذة…"], ["تعلّم مع العائلة.", "اطلب من أحد والديك أو أجدادك أن يقول لك كلمات لغته، وعلّمه كلماتك."], ["غنِّ واستمع.", "أغانٍ ورسوم متحركة وحكايات: تعتاد أذنك على الأصوات دون جهد."], ["راجع في الوقت المناسب.", "«للمراجعة» يعيد لك الكلمات قبل أن تنساها مباشرة. هذا سرّ الكلمات التي تبقى."]],
  ou_bouche_titre:"كيف يصنع الفم هذه الكلمة", ou_nez:"الهواء يمرّ من الأنف", ou_voix:"الحلق يهتزّ", ou_normal:"عادي", ou_lent:"ببطء", ou_fermer:"إغلاق", ou_schema_note:"رسم بسيط للمساعدة؛ يبقى الصوت أفضل نموذج.", ou_bouche_btn:"شاهد الفم"
},
tr:{
  blagues:["Hoppala! Dün bir sokak lambasına merhaba dedim. Herkes yanılır!", "Sorun değil! Baykuşlar bile yanılır… hele gece yarısı atıştırmasından önce.", "Bu kelime bizimle saklambaç oynuyor. Bulalım mı?", "Denedin, beyin de işte böyle güçlenir!", "Hu hu! Benim tüylerim de birbirine karıştı. Bir kez daha?", "Bu kelime şakacı: kılık değiştirmiş! Daha dikkatli bakalım.", "Hata, «Beni yine ziyaret et!» diyen bir kelimedir.", "Büyük dedem baykuş kediyi şapkayla karıştırırdı. Gerçekten!", "Ah! Vahşi bir hata belirdi… Birlikte yakalayalım mı?", "Her hata bana bir bilgelik tüyü kazandırıyor. Teşekkürler!", "Az önce yeni bir kelime icat ettin! Ötekini arayalım mı?", "Hata koleksiyonu yapıyorum. Hepsi çok güzel."],
  lentement:"Yavaş dinle", bouche:"Ağzı gör", a_toi:"Sıra sende!", a_toi_aide:"Ami'yi dinle, sonra mikrofona bas ve kelimeyi söyle.", parler:"Konuş", j_ecoute:"Dinliyorum…", dis_le_mot:"Şimdi kelimeyi söyle!",
  me_reecouter:"Kendimi dinle", ecouter_ami:"Ami'yi dinle", a_toi_prive:"Sesin bu cihazda kalır: hiçbir şey gönderilmez ya da saklanmaz.", a_toi_bravo:"Bravo, konuşmaya cesaret ettin! Sesini Ami'ninkiyle karşılaştır.",
  sans_micro:"Mikrofon yok mu? Kelimeyi yüksek sesle söyle: bu bile harika!", je_l_ai_dit:"Söyledim!", reessayer:"Tekrar dene",
  mot_du_jour:"Günün kelimesi", astuce_ami:"Ami'nin ipucu", toutes_astuces:"Tüm ipuçları", astuces:"İpuçları", astuces_titre:"Başka bir dil nasıl konuşulur", astuces_intro:"Kimse bir dili konuşarak doğmaz: herkes onu yavaş yavaş öğrenir. İşte sırlarım.",
  conseils:[["Her gün biraz.", "Günde beş dakika, pazar günü bir saatten iyidir: beyin düzenli buluşmaları sever."], ["Yüksek sesle konuş.", "Her kelimeyi söyle, yalnız olsan bile. Sadece gözlerin değil, ağzın da öğrenir."], ["Yankı gibi tekrar et.", "Dinle, sonra aynı ezgiyle hemen tekrar et. 🐢 düğmesi zor kelimelerde yardım eder."], ["Yanılmaktan korkma.", "Kimse başta kusursuz konuşmaz. Her hata seni doğru kelimeye yaklaştırır."], ["Her yere kelime yapıştır.", "Evdeki eşyalara küçük etiketler koy: kapı, masa, pencere…"], ["Aileyle öğren.", "Bir ebeveynden ya da büyükanne-büyükbabadan kendi dilindeki kelimeleri söylemesini iste, sen de ona kendi kelimelerini öğret."], ["Şarkı söyle ve dinle.", "Şarkılar, çizgi filmler, masallar: kulağın seslere zahmetsizce alışır."], ["Doğru zamanda tekrar et.", "«Tekrar» kelimeleri sen unutmadan hemen önce sana geri verir. Akılda kalan kelimelerin sırrı budur."]],
  ou_bouche_titre:"Ağız bu kelimeyi nasıl çıkarır", ou_nez:"hava burundan geçer", ou_voix:"boğaz titrer", ou_normal:"Normal", ou_lent:"Yavaş", ou_fermer:"Kapat", ou_schema_note:"Yardım için basit bir çizim; en iyi örnek yine sestir.", ou_bouche_btn:"Ağzı gör"
},
pl:{
  blagues:["Ups! Wczoraj powiedziałem „dzień dobry” latarni. Każdy się myli!", "Nic nie szkodzi! Nawet sowy się mylą… zwłaszcza przed północną przekąską.", "To słowo bawi się z nami w chowanego. Znajdziemy je?", "Spróbowałeś – i właśnie tak mózg nabiera siły!", "Hu hu! Moje pióra też się poplątały. Jeszcze raz?", "To słowo jest żartownisiem: przebrało się! Popatrzmy uważniej.", "Błąd to słowo, które mówi: „Odwiedź mnie znowu!”", "Mój pradziadek puchacz mylił kota z kapeluszem. Naprawdę!", "Och! Pojawia się dziki błąd… Złapiemy go razem?", "Po każdym błędzie rośnie mi pióro mądrości. Dziękuję!", "Właśnie wymyśliłeś nowe słowo! Poszukamy tego drugiego?", "Kolekcjonuję błędy. Wszystkie są bardzo ładne."],
  lentement:"Słuchaj powoli", bouche:"Zobacz usta", a_toi:"Twoja kolej!", a_toi_aide:"Posłuchaj Amiego, potem naciśnij mikrofon i powiedz słowo.", parler:"Mów", j_ecoute:"Słucham…", dis_le_mot:"Powiedz teraz słowo!",
  me_reecouter:"Posłuchaj siebie", ecouter_ami:"Posłuchaj Amiego", a_toi_prive:"Twój głos zostaje na tym urządzeniu: nic nie jest wysyłane ani zapisywane.", a_toi_bravo:"Brawo, odważyłeś się mówić! Porównaj swój głos z głosem Amiego.",
  sans_micro:"Brak mikrofonu? Powiedz słowo na głos: to już świetnie!", je_l_ai_dit:"Powiedziałem!", reessayer:"Jeszcze raz",
  mot_du_jour:"Słowo dnia", astuce_ami:"Rada Amiego", toutes_astuces:"Wszystkie rady", astuces:"Rady", astuces_titre:"Jak mówić w innym języku", astuces_intro:"Nikt nie rodzi się, mówiąc w jakimś języku: każdy uczy się go krok po kroku. Oto moje sekrety.",
  conseils:[["Trochę każdego dnia.", "Pięć minut dziennie jest lepsze niż godzina w niedzielę: mózg lubi regularne spotkania."], ["Mów na głos.", "Wypowiadaj każde słowo, nawet w samotności. Twoje usta też się uczą, nie tylko oczy."], ["Powtarzaj jak echo.", "Posłuchaj i od razu powtórz z tą samą melodią. Przycisk 🐢 pomaga przy trudnych słowach."], ["Nie bój się błędów.", "Nikt na początku nie mówi idealnie. Każdy błąd przybliża cię do właściwego słowa."], ["Przyklejaj słowa wszędzie.", "Przyklej małe karteczki na rzeczy w domu: drzwi, stół, okno…"], ["Ucz się z rodziną.", "Poproś rodzica lub dziadka, żeby powiedział ci słowa w swoim języku, i naucz go swoich."], ["Śpiewaj i słuchaj.", "Piosenki, bajki, opowieści: twoje ucho bez wysiłku przyzwyczaja się do dźwięków."], ["Powtarzaj we właściwym momencie.", "„Do powtórki” oddaje ci słowa tuż przed tym, jak je zapomnisz. To sekret słów, które zostają."]],
  ou_bouche_titre:"Jak usta wymawiają to słowo", ou_nez:"powietrze idzie przez nos", ou_voix:"gardło drga", ou_normal:"Normalnie", ou_lent:"Powoli", ou_fermer:"Zamknij", ou_schema_note:"Prosty rysunek jako pomoc; najlepszym wzorem pozostaje głos.", ou_bouche_btn:"Zobacz usta"
},
uk:{
  blagues:["Ой! Учора я привітався з ліхтарем. Усі помиляються!", "Нічого страшного! Навіть сови помиляються… особливо перед опівнічним перекусом.", "Це слово грає з нами в хованки. Знайдемо його?", "Ти спробував — і саме так мозок стає сильнішим!", "Ух-ух! Моє пір'я теж заплуталося. Ще раз?", "Це слово — жартівник: воно перевдяглося! Придивімося краще.", "Помилка — це слово, яке каже: «Приходь до мене знову!»", "Мій прадід-пугач плутав кота з капелюхом. Чесно!", "О! З'явилася дика помилка… Зловимо її разом?", "Від кожної помилки в мене виростає перо мудрості. Дякую!", "Ти щойно вигадав нове слово! Пошукаємо інше?", "Я колекціоную помилки. Вони всі дуже гарні."],
  lentement:"Слухати повільно", bouche:"Побачити рот", a_toi:"Твоя черга!", a_toi_aide:"Послухай Амі, потім натисни мікрофон і скажи слово.", parler:"Говорити", j_ecoute:"Я слухаю…", dis_le_mot:"Скажи слово зараз!",
  me_reecouter:"Послухати себе", ecouter_ami:"Послухати Амі", a_toi_prive:"Твій голос залишається на цьому пристрої: нічого не надсилається й не зберігається.", a_toi_bravo:"Молодець, ти наважився говорити! Порівняй свій голос із голосом Амі.",
  sans_micro:"Немає мікрофона? Скажи слово вголос: це вже чудово!", je_l_ai_dit:"Я сказав!", reessayer:"Ще раз",
  mot_du_jour:"Слово дня", astuce_ami:"Порада Амі", toutes_astuces:"Усі поради", astuces:"Поради", astuces_titre:"Як заговорити іншою мовою", astuces_intro:"Ніхто не народжується, вже розмовляючи мовою: кожен вчить її крок за кроком. Ось мої секрети.",
  conseils:[["Потроху щодня.", "П'ять хвилин щодня кращі за годину в неділю: мозок любить регулярні зустрічі."], ["Говори вголос.", "Промовляй кожне слово, навіть наодинці. Твій рот теж вчиться, а не лише очі."], ["Повторюй, як луна.", "Послухай і одразу повтори з тією самою мелодією. Кнопка 🐢 допомагає з важкими словами."], ["Не бійся помилок.", "Ніхто не говорить ідеально на початку. Кожна помилка наближає тебе до правильного слова."], ["Клей слова скрізь.", "Наклей маленькі наліпки на речі вдома: двері, стіл, вікно…"], ["Вчися з родиною.", "Попроси батьків або бабусю чи дідуся сказати тобі слова їхньою мовою, а ти навчи їх своїх."], ["Співай і слухай.", "Пісні, мультфільми, казки: твоє вухо без зусиль звикає до звуків."], ["Повторюй вчасно.", "«Повторити» повертає тобі слова якраз перед тим, як ти їх забудеш. Це секрет слів, які залишаються."]],
  ou_bouche_titre:"Як рот вимовляє це слово", ou_nez:"повітря йде через ніс", ou_voix:"горло вібрує", ou_normal:"Звичайно", ou_lent:"Повільно", ou_fermer:"Закрити", ou_schema_note:"Простий малюнок на допомогу; найкращий зразок — голос.", ou_bouche_btn:"Побачити рот"
},
ja:{
  blagues:["おっと！きのう街灯にこんにちはって言っちゃった。だれでもまちがえるよ！", "だいじょうぶ！フクロウだってまちがえる…とくに真夜中のおやつの前はね。", "このことば、かくれんぼしてるみたい。見つけようか？", "やってみたね。そうやって脳は強くなるんだ！", "ホーホー！ぼくの羽もからまっちゃった。もう一回？", "このことばはいたずらっ子。変装してるよ！よく見てみよう。", "まちがいは「また会いにきてね！」って言うことばなんだ。", "ぼくのひいおじいちゃんフクロウは、ネコとぼうしをまちがえてたよ。本当だよ！", "あっ！野生のまちがいがあらわれた…いっしょにつかまえよう？", "まちがえるたびに、ちえの羽が一本生えるんだ。ありがとう！", "新しいことばを発明したね！もうひとつのほうをさがそうか？", "ぼくはまちがいを集めてるんだ。どれもすごくきれいだよ。"],
  lentement:"ゆっくり聞く", bouche:"口を見る", a_toi:"きみの番！", a_toi_aide:"アミの声を聞いて、マイクをおしてことばを言ってね。", parler:"話す", j_ecoute:"聞いてるよ…", dis_le_mot:"いま、ことばを言って！",
  me_reecouter:"自分の声を聞く", ecouter_ami:"アミの声を聞く", a_toi_prive:"きみの声はこの端末にだけ残り、送信も保存もされません。", a_toi_bravo:"すごい、話してみたね！自分の声とアミの声をくらべてみよう。",
  sans_micro:"マイクがない？声に出して言ってみよう。それだけでもすばらしい！", je_l_ai_dit:"言えた！", reessayer:"もう一度",
  mot_du_jour:"今日のことば", astuce_ami:"アミのヒント", toutes_astuces:"ヒントをすべて見る", astuces:"ヒント", astuces_titre:"ほかの言語を話すには", astuces_intro:"生まれたときから話せる人はいません。だれもが少しずつ覚えていきます。ぼくの秘密を教えるね。",
  conseils:[["毎日すこしずつ。", "日曜日に1時間より、毎日5分のほうがいい。脳は決まった時間の約束が大好き。"], ["声に出して話そう。", "ひとりでも、ことばを一つずつ声に出そう。目だけでなく口も覚えるよ。"], ["こだまのようにくり返そう。", "聞いたらすぐ、同じメロディでまねしよう。むずかしいことばは🐢ボタンが助けてくれる。"], ["まちがいをこわがらないで。", "最初から完ぺきに話せる人はいない。まちがえるたびに正しいことばに近づくよ。"], ["ことばをあちこちにはろう。", "家の物に小さなラベルをはろう。ドア、テーブル、まど…"], ["家族といっしょに学ぼう。", "お父さんやお母さん、おじいちゃんおばあちゃんに、その人のことばを教えてもらおう。きみのことばも教えてあげて。"], ["歌って、聞こう。", "歌、アニメ、お話。耳が自然に音になれていくよ。"], ["ちょうどいいときに復習しよう。", "「復習」は、わすれる直前にことばをもう一度見せてくれる。それが覚えたことばが残るひみつ。"]],
  ou_bouche_titre:"口はこのことばをどう言う？", ou_nez:"空気が鼻を通る", ou_voix:"のどがふるえる", ou_normal:"ふつう", ou_lent:"ゆっくり", ou_fermer:"閉じる", ou_schema_note:"助けになるかんたんな絵です。いちばんのお手本は声です。", ou_bouche_btn:"口を見る"
}
};
for(const l in V) if(window.TEXTES[l]) Object.assign(window.TEXTES[l], V[l]);
})();
